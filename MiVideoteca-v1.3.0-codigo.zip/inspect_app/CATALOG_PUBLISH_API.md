# Contrato de publicación de catalogo.json

La URL pública configurada en **Configuración → Catálogo** sigue siendo de lectura y debe responder a `GET` con el catálogo vigente.

La URL administrativa es independiente y debe aceptar:

```http
PUT /admin/catalogo
Authorization: Bearer CLAVE_PRIVADA
Content-Type: application/json; charset=utf-8
```

El cuerpo es el `catalogo.json` completo. El servidor debe:

1. validar la clave sin escribirla en logs;
2. limitar el tamaño de la solicitud;
3. comprobar JSON, `schema_version`, estructura e IDs duplicados;
4. guardar primero en un archivo o valor temporal;
5. reemplazar la versión pública solamente después de validar;
6. responder con HTTP 2xx únicamente cuando la nueva versión esté disponible para lectura;
7. devolver 401/403 para credenciales inválidas, 409/412 para conflictos y 4xx para JSON inválido.

La aplicación vuelve a consultar la URL pública después del `PUT` y no muestra confirmación si faltan entradas.

La URL actual del Worker puede continuar usándose para descargar. Para publicar desde Android es necesario ampliar ese Worker con este endpoint protegido; una URL que solamente responde a `GET` no puede recibir actualizaciones.
