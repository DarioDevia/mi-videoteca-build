# Mi Videoteca Android

Aplicación Android nativa (Kotlin + Jetpack Compose) para consultar un catálogo audiovisual, conservar favoritos/progreso local, abrir contenido en Telegram y preparar publicaciones de películas.

## Versión 1.3.0

- Tráiler silencioso de fondo en la ficha cuando TMDB o AniList ofrece uno, con imagen de respaldo.
- Opción para desactivar los tráileres en Configuración > Apariencia > Opciones avanzadas.
- Administración de películas, series (TMDB) y anime (AniList).
- Explicación integrada de cómo se combinan, exportan y publican los catálogos.
- Verificación de Telegram con progreso y resultado visibles.
- Estado de Telegram dentro de Diagnóstico > Probar servicios.
- Nueva animación breve al iniciar y nuevo icono de Administrar.

## Compilar

Requisitos: JDK 17, Android SDK 34 y conexión a Google Maven/Maven Central la primera vez.

```bash
./gradlew assembleDebug
```

La APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Catálogo

La URL remota inicial es:

```text
https://small-breeze-e454.deviadario.workers.dev/
```

Puede cambiarse desde **Configuración → Catálogo** sin recompilar la aplicación. La descarga nueva se valida antes de reemplazar la copia anterior. También se admite cualquier proveedor visible mediante el selector estándar de archivos de Android; la app copia el JSON válido a su espacio privado y no solicita acceso general al almacenamiento.

Se admite `schema_version` 1.x. Campos mínimos por elemento:

- `id`: identificador único y estable.
- `tipo`: `pelicula`, `serie` o `anime`.
- `titulo`.
- `tmdb_id` para películas/series o `anilist_id` para anime; alternativamente puede incluirse `poster_url`.
- `telegram_url` opcional, pero si existe debe ser HTTPS con host `t.me` o `telegram.me`.

Campos opcionales útiles: `titulo_original`, `titulos_alternativos`, `year`, `generos`, `sinopsis`, `poster_url`, `backdrop_url`, `trailer_url`, `fecha_agregado`, `audio`, `subtitulos` y `temporadas`.

Cada temporada tiene `numero`, `titulo` opcional y `episodios`. Cada episodio tiene `id`, `numero` y opcionalmente `titulo`, `duracion`, `thumbnail_url` y `telegram_url`.

Consultá [catalogo.schema.json](catalogo.schema.json) para la definición completa.

## Metadatos y secretos

- AniList usa su API pública sin clave.
- El token de lectura de TMDB se introduce desde Configuración y se guarda en el almacenamiento privado de la aplicación.
- El token no se incluye en el código, en el APK de origen ni en los registros de diagnóstico.
- Para una distribución pública, un token dentro de una app cliente nunca puede considerarse secreto absoluto; conviene usar un backend intermedio.

## Administración de películas

**Administrar → Película** permite buscar manualmente en TMDB, elegir el resultado correcto, cargar ficha y créditos, editar la plantilla completa y publicar poster + caption en un canal de Telegram.

La publicación utiliza Telegram Bot API. En **Configuración → Telegram** se guardan un Bot Token y el destino específico de películas. El token se cifra con una clave AES/GCM generada por Android Keystore y nunca se muestra completo ni se escribe en los logs. El bot debe ser administrador del canal y tener permiso para publicar mensajes.

**Verificar conexión** solo consulta identidad, canal y permisos; no crea ni borra mensajes. Antes de publicar se exige una confirmación explícita, se valida el límite de 1024 caracteres y solo se informa éxito después de recibir un `message_id` de Telegram. El recibo se conserva localmente para una integración futura.

Anime y Series figuran como extensiones futuras. Esta versión no descarga, sube ni modifica videos y no usa FFmpeg. El catálogo solo cambia cuando el usuario agrega, edita, elimina, exporta o publica expresamente una entrada.

### Agregar películas al catálogo

Después de seleccionar una película en TMDB se puede pegar el enlace completo del mensaje que contiene el video y pulsar **Agregar a Mi Videoteca**. La entrada se guarda en un catálogo JSON administrado por la aplicación y se fusiona con la fuente activa mediante `id` y `tmdb_id`. De esta manera una actualización remota no borra las incorporaciones manuales.

Desde **Administrar → Catálogo** se puede:

- revisar, editar el enlace o eliminar incorporaciones manuales;
- guardar un `catalogo.json` completo mediante Storage Access Framework;
- compartir el archivo mediante el selector estándar de Android;
- publicar el catálogo completo en un servidor configurado.

La publicación online usa una petición HTTPS `PUT` con `Content-Type: application/json` y `Authorization: Bearer <clave>`. Después de recibir una respuesta satisfactoria, la app descarga la URL pública y comprueba que incluya todas las entradas esperadas. La clave administrativa se cifra con Android Keystore. Consultá [CATALOG_PUBLISH_API.md](CATALOG_PUBLISH_API.md) para el contrato requerido del servidor.

## Persistencia

Los datos se separan por `profileId`. La versión actual crea el perfil `mi_videoteca`; esta separación permite incorporar más perfiles posteriormente. Cada perfil conserva su URL, archivo local copiado, selección de fuente, caché de catálogo, metadatos, favoritos y progreso.

El progreso registra aperturas, vistos y último episodio; no inventa una posición temporal porque la reproducción ocurre fuera de la app.
