package com.mivideoteca.app

import com.mivideoteca.app.data.ProductionCountry
import com.mivideoteca.app.data.PublicationFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class PublicationFormatterTest {
    @Test
    fun `uses requested movie template and line breaks`() {
        val text = PublicationFormatter.movieCaption(
            title = "This Is the End",
            year = "2013",
            latinTitle = "Este es el fin",
            synopsis = "Una fiesta se convierte en el fin del mundo.",
            cast = listOf("James Franco", "Seth Rogen"),
            directors = listOf("Evan Goldberg", "Seth Rogen"),
            countries = listOf(ProductionCountry("US", "Estados Unidos", "🇺🇸"))
        )
        assertEquals(
            "This Is the End (2013)\n-Este es el fin\n\nSINOPSIS: Una fiesta se convierte en el fin del mundo.\n\nREPARTO:\nJames Franco, Seth Rogen.\n\nDirigida por: Evan Goldberg y Seth Rogen\nEstados Unidos 🇺🇸",
            text
        )
    }

    @Test
    fun `omits missing values instead of placeholders`() {
        val text = PublicationFormatter.movieCaption("Película", null, null, null, emptyList(), emptyList(), emptyList())
        assertEquals("Película", text)
        assertFalse(text.contains("null"))
        assertFalse(text.contains("N/A"))
    }

    @Test
    fun `derives flags only from valid country codes`() {
        assertEquals("🇦🇷", PublicationFormatter.countryFlag("AR"))
        assertEquals("🇯🇵", PublicationFormatter.countryFlag("jp"))
        assertEquals("", PublicationFormatter.countryFlag("ARG"))
    }
}
