package com.mivideoteca.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CatalogValidatorTest {
    private val validator = CatalogValidator()

    @Test
    fun validEntriesLoadAndInvalidEntriesAreReported() {
        val json = """
            {
              "schema_version": "1.2.0",
              "items": [
                {"id":"ok","tipo":"anime","titulo":"Válido","anilist_id":1,"telegram_url":"https://t.me/c/1/2"},
                {"id":"bad","tipo":"cosa","titulo":"Inválido"}
              ]
            }
        """.trimIndent()
        val result = validator.validate(json, "prueba")
        assertEquals(1, result.items.size)
        assertEquals(1, result.issues.size)
    }

    @Test
    fun incompatibleSchemaIsRejected() {
        val json = """{"schema_version":"2.0","items":[]}"""
        assertThrows(IllegalArgumentException::class.java) { validator.validate(json, "prueba") }
    }

    @Test
    fun numericSchemaAndMinimalAnilistEntryAreAccepted() {
        val json = """{"schema_version":1,"items":[{"id":"anime-1","tipo":"anime","titulo":"Demo","anilist_id":1,"telegram_url":"https://t.me/c/1/2"}]}"""
        assertEquals(1, validator.validate(json, "worker").items.size)
    }
}
