package com.mivideoteca.app

import com.google.gson.GsonBuilder
import com.mivideoteca.app.data.CatalogValidator
import com.mivideoteca.app.data.CatalogoResponse
import com.mivideoteca.app.data.VideoItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ManualCatalogTest {
    @Test
    fun `generated movie is a valid shareable catalog entry`() {
        val item = VideoItem(
            id = "pelicula-tmdb-123",
            tipo = "pelicula",
            titulo = "Película de prueba",
            tmdbId = 123,
            posterUrl = "https://image.tmdb.org/t/p/w780/poster.jpg",
            telegramUrl = "https://t.me/c/1692370597/1847",
            fechaAgregado = "2026-09-21"
        )
        val json = GsonBuilder().setPrettyPrinting().create()
            .toJson(CatalogoResponse("1.0", "2026-09-21T00:00:00Z", listOf(item)))
        val snapshot = CatalogValidator().validate(json, "Prueba")
        assertEquals(1, snapshot.items.size)
        assertEquals(123L, snapshot.items.first().tmdbId)
        assertTrue(snapshot.items.first().telegramUrl!!.endsWith("/1847"))
    }
}
