package com.mivideoteca.app.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

class AppStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("videoteca_settings_v2", Context.MODE_PRIVATE)
    private val gson = Gson()

    private fun key(profileId: String, name: String) = "profile.$profileId.$name"

    fun loadPreferences(profileId: String = prefs.getString("active_profile", "mi_videoteca")!!): AppPreferences {
        return AppPreferences(
            profileId = profileId,
            profileName = prefs.getString(key(profileId, "name"), "Mi Videoteca")!!,
            source = enumValue(prefs.getString(key(profileId, "source"), null), CatalogSource.REMOTE),
            remoteUrl = prefs.getString(key(profileId, "remote_url"), CatalogRepository.DEFAULT_URL)!!,
            localFileName = prefs.getString(key(profileId, "local_name"), null),
            tmdbToken = prefs.getString(key(profileId, "tmdb_token"), "")!!,
            metadataLanguage = prefs.getString(key(profileId, "language"), "es-AR")!!,
            themeMode = enumValue(prefs.getString(key(profileId, "theme"), null), ThemeMode.DARK),
            showAnime = prefs.getBoolean(key(profileId, "show_anime"), true),
            showMovies = prefs.getBoolean(key(profileId, "show_movies"), true),
            showSeries = prefs.getBoolean(key(profileId, "show_series"), true),
            sortMode = enumValue(prefs.getString(key(profileId, "sort"), null), SortMode.RECENT),
            rememberOpenedEpisodes = prefs.getBoolean(key(profileId, "remember_episodes"), true),
            markWatchedOnOpen = prefs.getBoolean(key(profileId, "mark_on_open"), false),
            confirmMarkWatched = prefs.getBoolean(key(profileId, "confirm_mark"), true),
            openWithTelegram = prefs.getBoolean(key(profileId, "telegram"), true),
            autoplayTrailers = prefs.getBoolean(key(profileId, "autoplay_trailers"), true),
            telegramMovieChatId = prefs.getString(key(profileId, "telegram_movie_chat_id"), "")!!,
            telegramMovieChannelTitle = prefs.getString(key(profileId, "telegram_movie_channel_title"), null),
            catalogPublishUrl = prefs.getString(key(profileId, "catalog_publish_url"), "")!!
        )
    }

    fun savePreferences(value: AppPreferences) {
        prefs.edit()
            .putString("active_profile", value.profileId)
            .putString(key(value.profileId, "name"), value.profileName)
            .putString(key(value.profileId, "source"), value.source.name)
            .putString(key(value.profileId, "remote_url"), value.remoteUrl)
            .putString(key(value.profileId, "local_name"), value.localFileName)
            .putString(key(value.profileId, "tmdb_token"), value.tmdbToken)
            .putString(key(value.profileId, "language"), value.metadataLanguage)
            .putString(key(value.profileId, "theme"), value.themeMode.name)
            .putBoolean(key(value.profileId, "show_anime"), value.showAnime)
            .putBoolean(key(value.profileId, "show_movies"), value.showMovies)
            .putBoolean(key(value.profileId, "show_series"), value.showSeries)
            .putString(key(value.profileId, "sort"), value.sortMode.name)
            .putBoolean(key(value.profileId, "remember_episodes"), value.rememberOpenedEpisodes)
            .putBoolean(key(value.profileId, "mark_on_open"), value.markWatchedOnOpen)
            .putBoolean(key(value.profileId, "confirm_mark"), value.confirmMarkWatched)
            .putBoolean(key(value.profileId, "telegram"), value.openWithTelegram)
            .putBoolean(key(value.profileId, "autoplay_trailers"), value.autoplayTrailers)
            .putString(key(value.profileId, "telegram_movie_chat_id"), value.telegramMovieChatId)
            .putString(key(value.profileId, "telegram_movie_channel_title"), value.telegramMovieChannelTitle)
            .putString(key(value.profileId, "catalog_publish_url"), value.catalogPublishUrl)
            .apply()
    }

    fun progress(profileId: String): Map<String, UserProgress> {
        val json = prefs.getString(key(profileId, "progress"), "{}")!!
        val type = object : TypeToken<Map<String, UserProgress>>() {}.type
        return runCatching { gson.fromJson<Map<String, UserProgress>>(json, type) }.getOrDefault(emptyMap())
    }

    fun saveProgress(profileId: String, values: Map<String, UserProgress>) {
        prefs.edit().putString(key(profileId, "progress"), gson.toJson(values)).apply()
    }

    fun favorites(profileId: String): Set<String> =
        prefs.getStringSet(key(profileId, "favorites"), emptySet())?.toSet() ?: emptySet()

    fun saveFavorites(profileId: String, values: Set<String>) {
        prefs.edit().putStringSet(key(profileId, "favorites"), values).apply()
    }

    fun savePublicationReceipt(profileId: String, receipt: PublicationReceipt) {
        val file = File(profileDir(profileId), "publications.jsonl")
        runCatching { file.appendText(gson.toJson(receipt) + "\n") }
    }

    fun logAdministrationError(profileId: String, message: String) {
        val sanitized = message
            .replace(Regex("bot[0-9]+:[A-Za-z0-9_-]+", RegexOption.IGNORE_CASE), "bot***")
            .replace(Regex("Bearer\\s+\\S+", RegexOption.IGNORE_CASE), "Bearer ***")
        runCatching {
            File(profileDir(profileId), "administration_errors.log")
                .appendText("${System.currentTimeMillis()} | $sanitized\n")
        }
    }

    fun recentAdministrationErrors(profileId: String): List<String> =
        File(profileDir(profileId), "administration_errors.log")
            .takeIf(File::exists)?.readLines()?.takeLast(30)?.reversed() ?: emptyList()

    fun clearAdministrationErrors(profileId: String) {
        File(profileDir(profileId), "administration_errors.log").delete()
    }

    fun profileDir(profileId: String): File = File(context.filesDir, "profiles/$profileId").apply { mkdirs() }

    private inline fun <reified T : Enum<T>> enumValue(raw: String?, fallback: T): T =
        runCatching { enumValueOf<T>(raw ?: "") }.getOrDefault(fallback)
}
