package com.mivideoteca.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.imageLoader
import coil.annotation.ExperimentalCoilApi
import com.mivideoteca.app.data.*
import com.mivideoteca.app.ui.MiVideotecaTheme
import com.mivideoteca.app.ui.screens.*
import com.mivideoteca.app.security.SecureSecretStore
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = AppStore(this)
        val repository = CatalogRepository(this, store)
        val metadataRepository = MetadataRepository(store)
        val secretStore = SecureSecretStore(this)
        val telegramRepository = TelegramPublisherRepository(store)
        setContent { VideotecaApp(store, repository, metadataRepository, telegramRepository, secretStore) }
    }
}

@Composable
@OptIn(ExperimentalCoilApi::class)
private fun VideotecaApp(
    store: AppStore,
    repository: CatalogRepository,
    metadataRepository: MetadataRepository,
    telegramRepository: TelegramPublisherRepository,
    secretStore: SecureSecretStore
) {
    var preferences by remember { mutableStateOf(store.loadPreferences()) }
    var snapshot by remember { mutableStateOf<CatalogSnapshot?>(null) }
    var progress by remember { mutableStateOf(store.progress(preferences.profileId)) }
    var favorites by remember { mutableStateOf(store.favorites(preferences.profileId)) }
    var route by remember { mutableStateOf("home") }
    var selectedItem by remember { mutableStateOf<VideoItem?>(null) }
    var loading by remember { mutableStateOf(true) }
    var notice by remember { mutableStateOf<String?>(null) }
    var services by remember { mutableStateOf(ServiceStatus()) }
    var showIntro by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    fun savePrefs(newValue: AppPreferences, reload: Boolean = false) {
        preferences = newValue
        store.savePreferences(newValue)
        if (reload) {
            scope.launch {
                loading = true
                runCatching { repository.loadActive(newValue, refreshRemote = false) }
                    .onSuccess { snapshot = it; notice = null }
                    .onFailure { notice = it.message }
                loading = false
            }
        }
    }

    fun refresh(forceNetwork: Boolean = true) {
        scope.launch {
            loading = true
            runCatching { repository.loadActive(preferences, refreshRemote = forceNetwork) }
                .onSuccess { snapshot = it; notice = null }
                .onFailure { notice = it.message }
            loading = false
        }
    }

    fun saveProgress(value: UserProgress) {
        progress = progress + (value.itemId to value)
        store.saveProgress(preferences.profileId, progress)
    }

    fun opened(item: VideoItem, episode: Episode? = null, markWatched: Boolean = false) {
        val old = progress[item.id] ?: UserProgress(item.id)
        val episodeIds = if (markWatched && episode != null) old.watchedEpisodeIds + episode.id else old.watchedEpisodeIds
        saveProgress(old.copy(
            lastEpisodeId = if (preferences.rememberOpenedEpisodes) episode?.id ?: old.lastEpisodeId else old.lastEpisodeId,
            watchedItem = if (episode == null && markWatched) true else old.watchedItem,
            watchedEpisodeIds = episodeIds,
            lastAccessMillis = System.currentTimeMillis()
        ))
    }

    fun select(item: VideoItem) {
        selectedItem = item
        opened(item)
        scope.launch {
            val enriched = metadataRepository.enrich(item, preferences)
            if (selectedItem?.id == item.id) selectedItem = enriched
        }
    }

    LaunchedEffect(Unit) {
        refresh(true)
        delay(1200)
        showIntro = false
    }

    MiVideotecaTheme(preferences.themeMode) {
        Box(Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                if (selectedItem == null && route != "diagnostics" && route != "about") {
                    NavigationBar {
                        listOf(
                            Triple("home", "Inicio", Icons.Default.Home),
                            Triple("search", "Buscar", Icons.Default.Search),
                            Triple("favorites", "Mi lista", Icons.Default.Favorite),
                            Triple("admin", "Administrar", Icons.Default.VideoLibrary),
                            Triple("settings", "Configuración", Icons.Default.Settings)
                        ).forEach { (target, label, icon) ->
                            NavigationBarItem(
                                selected = route == target,
                                onClick = { route = target },
                                icon = { Icon(icon, label) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when {
                    selectedItem != null -> DetailScreen(
                        item = selectedItem!!,
                        progress = progress[selectedItem!!.id],
                        favorite = selectedItem!!.id in favorites,
                        preferences = preferences,
                        onBack = { selectedItem = null },
                        onToggleFavorite = {
                            favorites = if (it.id in favorites) favorites - it.id else favorites + it.id
                            store.saveFavorites(preferences.profileId, favorites)
                        },
                        onOpen = { item, episode, watched -> opened(item, episode, watched) }
                    )
                    route == "diagnostics" -> DiagnosticsScreen(
                        preferences = preferences,
                        snapshot = snapshot,
                        services = services,
                        errors = repository.recentErrors(preferences.profileId) + store.recentAdministrationErrors(preferences.profileId),
                        onBack = { route = "settings" },
                        onTest = {
                            scope.launch {
                                services = ServiceStatus("Probando…", "Probando…", "Probando…", "Probando…")
                                val base = repository.testServices(preferences)
                                val telegram = if (!secretStore.hasTelegramBotToken() || preferences.telegramMovieChatId.isBlank()) {
                                    "Sin configurar"
                                } else {
                                    runCatching {
                                        telegramRepository.verifyConnection(secretStore.getTelegramBotToken(), preferences.telegramMovieChatId).detail
                                    }.getOrElse { it.message ?: "No se pudo verificar" }
                                }
                                services = base.copy(telegram = telegram)
                            }
                        },
                        onClearErrors = {
                            repository.clearErrors(preferences.profileId)
                            store.clearAdministrationErrors(preferences.profileId)
                        }
                    )
                    route == "about" -> AboutScreen(snapshot, onBack = { route = "settings" })
                    route == "home" -> HomeScreen(
                        snapshot = snapshot,
                        preferences = preferences,
                        progress = progress,
                        loading = loading,
                        notice = notice,
                        onSelect = ::select,
                        onRefresh = { refresh(true) }
                    )
                    route == "search" -> SearchScreen(snapshot?.items.orEmpty(), preferences, onSelect = ::select)
                    route == "favorites" -> FavoritesScreen(
                        snapshot?.items.orEmpty().filter { it.id in favorites },
                        onSelect = ::select
                    )
                    route == "admin" -> AdminScreen(
                        preferences = preferences,
                        snapshot = snapshot,
                        catalogRepository = repository,
                        metadataRepository = metadataRepository,
                        telegramRepository = telegramRepository,
                        secretStore = secretStore,
                        store = store,
                        onCatalogChanged = { snapshot = it; notice = null }
                    )
                    route == "settings" -> SettingsScreen(
                        preferences = preferences,
                        snapshot = snapshot,
                        repository = repository,
                        telegramRepository = telegramRepository,
                        secretStore = secretStore,
                        imageCacheBytes = context.imageLoader.diskCache?.size ?: 0L,
                        onPreferencesChanged = ::savePrefs,
                        onRemoteUpdated = { snapshot = it; notice = null },
                        onLocalImported = { snap, name ->
                            val updated = preferences.copy(localFileName = name, source = CatalogSource.LOCAL)
                            savePrefs(updated)
                            snapshot = snap
                        },
                        onClearImages = {
                            context.imageLoader.memoryCache?.clear()
                            context.imageLoader.diskCache?.clear()
                        },
                        onClearMetadata = { repository.clearMetadataCache(preferences.profileId) },
                        onDiagnostics = { route = "diagnostics" },
                        onAbout = { route = "about" }
                    )
                }
            }
        }
        AnimatedVisibility(
            visible = showIntro,
            exit = fadeOut() + scaleOut(targetScale = .96f),
            modifier = Modifier.fillMaxSize()
        ) {
            Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                    Icon(Icons.Default.VideoLibrary, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.height(78.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("Mi Videoteca", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
        }
    }
}
