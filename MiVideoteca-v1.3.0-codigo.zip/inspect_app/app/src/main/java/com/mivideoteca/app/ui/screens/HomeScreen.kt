package com.mivideoteca.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.mivideoteca.app.data.*

@Composable
fun HomeScreen(
    snapshot: CatalogSnapshot?,
    preferences: AppPreferences,
    progress: Map<String, UserProgress>,
    loading: Boolean,
    notice: String?,
    onSelect: (VideoItem) -> Unit,
    onRefresh: () -> Unit
) {
    val items = filteredSorted(snapshot?.items.orEmpty(), preferences, progress)
    val hero = items.firstOrNull()
    val continueWatching = items.filter { (progress[it.id]?.lastAccessMillis ?: 0) > 0 }
        .sortedByDescending { progress[it.id]?.lastAccessMillis }
    val recent = items.filter { !it.fechaAgregado.isNullOrBlank() }.sortedByDescending { it.fechaAgregado }.take(20)

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Mi Videoteca", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Actualizar catálogo") }
            }
        }
        if (snapshot?.usingCachedCopy == true) {
            item { AssistChip(onClick = {}, label = { Text("Sin conexión: usando una copia almacenada") }, modifier = Modifier.padding(horizontal = 16.dp)) }
        }
        if (notice != null) item { Text(notice, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
        if (loading && snapshot == null) item { Box(Modifier.fillParentMaxHeight(.65f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        if (hero != null) item { HeroCard(hero, onSelect) }
        if (continueWatching.isNotEmpty()) item { MediaRow("Continuar viendo", continueWatching, progress, onSelect) }
        if (recent.isNotEmpty()) item { MediaRow("Agregados recientemente", recent, progress, onSelect) }
        val anime = items.filter { it.tipo == "anime" }
        val series = items.filter { it.tipo == "serie" }
        val movies = items.filter { it.tipo == "pelicula" }
        if (anime.isNotEmpty()) item { MediaRow("Anime", anime, progress, onSelect) }
        if (series.isNotEmpty()) item { MediaRow("Series", series, progress, onSelect) }
        if (movies.isNotEmpty()) item { MediaRow("Películas", movies, progress, onSelect) }
        if (!loading && items.isEmpty()) item {
            Text("No hay títulos para mostrar. Revisá la fuente del catálogo en Configuración.", modifier = Modifier.padding(24.dp))
        }
    }
}

@Composable
private fun HeroCard(item: VideoItem, onSelect: (VideoItem) -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(350.dp).clickable { onSelect(item) }
    ) {
        SubcomposeAsyncImage(
            model = item.backdropUrl ?: item.posterUrl,
            contentDescription = item.titulo,
            contentScale = ContentScale.Crop,
            loading = { Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant)) },
            error = { Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant)) },
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, MaterialTheme.colorScheme.background), startY = 100f)))
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp).fillMaxWidth(.86f)) {
            Text(item.titulo, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = Color.White)
            Text(
                listOfNotNull(item.tipo.replaceFirstChar { it.uppercase() }, item.year?.toString(), item.temporadas.takeIf { it.isNotEmpty() }?.let { "${it.sumOf { s -> s.episodios.size }} episodios" }).joinToString(" • "),
                color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.labelLarge
            )
            item.sinopsis?.let {
                Text(it, color = Color.White.copy(alpha = .85f), maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
            }
            Button(onClick = { onSelect(item) }, modifier = Modifier.padding(top = 12.dp)) {
                Icon(Icons.Default.Info, null); Spacer(Modifier.width(8.dp)); Text("Información")
            }
        }
    }
}

@Composable
private fun MediaRow(title: String, items: List<VideoItem>, progress: Map<String, UserProgress>, onSelect: (VideoItem) -> Unit) {
    Column(Modifier.padding(top = 18.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
            items(items, key = { it.id }) { item ->
                Box(Modifier.width(126.dp).clickable { onSelect(item) }) {
                    Poster(item, Modifier.fillMaxWidth())
                    if (progress[item.id]?.watchedItem == true) {
                        Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(6.dp), modifier = Modifier.align(Alignment.TopEnd).padding(5.dp)) {
                            Text("Visto", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                        }
                    }
                }
            }
        }
    }
}

private fun filteredSorted(items: List<VideoItem>, preferences: AppPreferences, progress: Map<String, UserProgress>): List<VideoItem> {
    val filtered = items.filter {
        when (it.tipo) {
            "anime" -> preferences.showAnime
            "pelicula" -> preferences.showMovies
            "serie" -> preferences.showSeries
            else -> false
        }
    }
    return when (preferences.sortMode) {
        SortMode.TITLE -> filtered.sortedBy { it.titulo.lowercase() }
        SortMode.RECENT -> filtered.sortedWith(compareByDescending<VideoItem> { it.fechaAgregado }.thenBy { it.titulo })
        SortMode.YEAR -> filtered.sortedByDescending { it.year ?: 0 }
        SortMode.LAST_VIEWED -> filtered.sortedByDescending { progress[it.id]?.lastAccessMillis ?: 0 }
    }
}
