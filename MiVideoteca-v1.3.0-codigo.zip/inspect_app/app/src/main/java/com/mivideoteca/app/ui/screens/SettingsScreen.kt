package com.mivideoteca.app.ui.screens

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.mivideoteca.app.BuildConfig
import com.mivideoteca.app.data.*
import com.mivideoteca.app.security.SecureSecretStore
import com.mivideoteca.app.util.TelegramLauncher
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun SettingsScreen(
    preferences: AppPreferences,
    snapshot: CatalogSnapshot?,
    repository: CatalogRepository,
    telegramRepository: TelegramPublisherRepository,
    secretStore: SecureSecretStore,
    imageCacheBytes: Long,
    onPreferencesChanged: (AppPreferences, Boolean) -> Unit,
    onRemoteUpdated: (CatalogSnapshot) -> Unit,
    onLocalImported: (CatalogSnapshot, String) -> Unit,
    onClearImages: () -> Unit,
    onClearMetadata: () -> Unit,
    onDiagnostics: () -> Unit,
    onAbout: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var remoteUrl by remember(preferences.profileId) { mutableStateOf(preferences.remoteUrl) }
    var token by remember(preferences.profileId) { mutableStateOf(preferences.tmdbToken) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var advanced by remember { mutableStateOf(false) }
    var catalogAdvanced by remember { mutableStateOf(false) }
    var imageBytes by remember { mutableLongStateOf(imageCacheBytes) }
    var metadataBytes by remember { mutableLongStateOf(repository.metadataCacheBytes(preferences.profileId)) }
    var telegramTokenInput by remember(preferences.profileId) { mutableStateOf("") }
    var telegramChatId by remember(preferences.profileId) { mutableStateOf(preferences.telegramMovieChatId) }
    var telegramReport by remember { mutableStateOf<TelegramConnectionReport?>(null) }
    var telegramBusy by remember { mutableStateOf(false) }
    var hasTelegramToken by remember { mutableStateOf(secretStore.hasTelegramBotToken()) }
    var catalogPublishUrl by remember(preferences.profileId) { mutableStateOf(preferences.catalogPublishUrl) }
    var catalogAdminTokenInput by remember(preferences.profileId) { mutableStateOf("") }
    var hasCatalogAdminToken by remember { mutableStateOf(secretStore.hasCatalogAdminToken()) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
            }.getOrNull() ?: "catalogo.json"
            scope.launch {
                busy = true
                runCatching { repository.importLocal(preferences.profileId, uri, name) }
                    .onSuccess { snap ->
                        onLocalImported(snap, name)
                        message = "Catálogo válido: ${snap.items.size} títulos y ${snap.issues.size} entradas ignoradas."
                    }
                    .onFailure { message = it.message ?: "No se pudo leer el archivo." }
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Configuración", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Perfil: ${preferences.profileName}", color = MaterialTheme.colorScheme.onSurface.copy(.65f))
        message?.let { AssistChip(onClick = { message = null }, label = { Text(it) }, modifier = Modifier.padding(top = 8.dp)) }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))

        SettingsCard("Catálogo", Icons.Default.Storage) {
            Text("Fuente del catálogo", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = preferences.source == CatalogSource.REMOTE,
                    onClick = { onPreferencesChanged(preferences.copy(source = CatalogSource.REMOTE, remoteUrl = remoteUrl), true) },
                    label = { Text("Remoto") }
                )
                FilterChip(
                    selected = preferences.source == CatalogSource.LOCAL,
                    onClick = { onPreferencesChanged(preferences.copy(source = CatalogSource.LOCAL), true) },
                    label = { Text("Archivo local") }
                )
            }
            if (preferences.source == CatalogSource.REMOTE) {
                OutlinedTextField(
                    value = remoteUrl,
                    onValueChange = { remoteUrl = it },
                    label = { Text("URL HTTPS de catalogo.json") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                busy = true
                                runCatching { repository.testRemote(remoteUrl) }
                                    .onSuccess { message = "Conexión correcta: ${it.items.size} títulos válidos, ${it.issues.size} con errores." }
                                    .onFailure { message = it.message }
                                busy = false
                            }
                        }, modifier = Modifier.weight(1f)
                    ) { Text("Probar conexión") }
                    Button(
                        onClick = {
                            val updated = preferences.copy(remoteUrl = remoteUrl, source = CatalogSource.REMOTE)
                            onPreferencesChanged(updated, false)
                            scope.launch {
                                busy = true
                                runCatching { repository.downloadRemote(updated, save = true) }
                                    .onSuccess { onRemoteUpdated(it); message = "Catálogo actualizado correctamente." }
                                    .onFailure { message = "No se reemplazó la copia anterior: ${it.message}" }
                                busy = false
                            }
                        }, modifier = Modifier.weight(1f)
                    ) { Text("Actualizar ahora") }
                }
            } else {
                Text("Archivo: ${preferences.localFileName ?: "Ninguno seleccionado"}")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { picker.launch(arrayOf("application/json", "text/json", "*/*")) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Seleccionar archivo")
                    }
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                busy = true
                                runCatching { repository.reloadLocal(preferences) }
                                    .onSuccess { onRemoteUpdated(it); message = "Copia local recargada." }
                                    .onFailure { message = it.message }
                                busy = false
                            }
                        }, modifier = Modifier.weight(1f)
                    ) { Text("Volver a cargar") }
                }
            }
            SnapshotSummary(snapshot)
            TextButton(onClick = { catalogAdvanced = !catalogAdvanced }) {
                Icon(if (catalogAdvanced) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                Text(if (catalogAdvanced) "Ocultar publicación online" else "Publicación online avanzada")
            }
            if (catalogAdvanced) {
                Text("Solo para el teléfono administrador. El servidor debe aceptar PUT con un token Bearer.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = catalogPublishUrl,
                    onValueChange = { catalogPublishUrl = it },
                    label = { Text("URL HTTPS para publicar catalogo.json") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = catalogAdminTokenInput,
                    onValueChange = { catalogAdminTokenInput = it },
                    label = { Text(if (hasCatalogAdminToken) "Nueva clave administrativa (opcional)" else "Clave administrativa") },
                    placeholder = { if (hasCatalogAdminToken) Text("Clave guardada de forma cifrada") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    runCatching {
                        if (catalogAdminTokenInput.isNotBlank()) {
                            secretStore.saveCatalogAdminToken(catalogAdminTokenInput)
                            catalogAdminTokenInput = ""
                            hasCatalogAdminToken = true
                        }
                        onPreferencesChanged(preferences.copy(catalogPublishUrl = catalogPublishUrl.trim()), false)
                        message = "Configuración de publicación online guardada."
                    }.onFailure { message = it.message ?: "No se pudo guardar la configuración." }
                }) { Text("Guardar publicación online") }
            }
        }

        SettingsCard("Metadatos", Icons.Default.Movie) {
            OutlinedTextField(
                value = token,
                onValueChange = { token = it },
                label = { Text("Token de lectura de TMDB") },
                supportingText = { Text("Se guarda en la zona privada de la app y nunca se escribe en los diagnósticos.") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Idioma", modifier = Modifier.weight(1f))
                listOf("es-AR", "es-ES", "en-US").forEach { language ->
                    FilterChip(
                        selected = preferences.metadataLanguage == language,
                        onClick = { onPreferencesChanged(preferences.copy(metadataLanguage = language, tmdbToken = token), false) },
                        label = { Text(language) },
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
            }
            Button(onClick = { onPreferencesChanged(preferences.copy(tmdbToken = token), false); message = "Configuración de metadatos guardada." }) { Text("Guardar") }
        }

        SettingsCard("Telegram", Icons.Default.Send) {
            Text("Canal de películas", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = telegramTokenInput,
                onValueChange = { telegramTokenInput = it; telegramReport = null },
                label = { Text(if (hasTelegramToken) "Nuevo Bot Token (opcional)" else "Bot Token") },
                placeholder = { if (hasTelegramToken) Text("Token guardado de forma cifrada") },
                supportingText = { Text("El token se cifra con Android Keystore y nunca se muestra completo ni se escribe en logs.") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = telegramChatId,
                onValueChange = { telegramChatId = it; telegramReport = null },
                label = { Text("ID o @usuario del canal") },
                supportingText = { Text("Para canales privados suele comenzar con -100. El bot debe ser administrador.") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        runCatching {
                            if (telegramTokenInput.isNotBlank()) {
                                secretStore.saveTelegramBotToken(telegramTokenInput)
                                telegramTokenInput = ""
                                hasTelegramToken = true
                            }
                            onPreferencesChanged(preferences.copy(telegramMovieChatId = telegramChatId.trim(), telegramMovieChannelTitle = null), false)
                            message = "Configuración de Telegram guardada."
                        }.onFailure { message = it.message ?: "No se pudo guardar la configuración." }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Guardar") }
                Button(
                    onClick = {
                        scope.launch {
                            busy = true; telegramBusy = true; telegramReport = null; message = "Consultando Telegram…"
                            runCatching {
                                if (telegramTokenInput.isNotBlank()) {
                                    secretStore.saveTelegramBotToken(telegramTokenInput)
                                    telegramTokenInput = ""
                                    hasTelegramToken = true
                                }
                                telegramRepository.verifyConnection(secretStore.getTelegramBotToken(), telegramChatId)
                            }.onSuccess { report ->
                                telegramReport = report
                                message = report.detail
                                val updated = preferences.copy(
                                    telegramMovieChatId = telegramChatId.trim(),
                                    telegramMovieChannelTitle = report.channelTitle
                                )
                                onPreferencesChanged(updated, false)
                            }.onFailure { message = it.message ?: "No se pudo verificar Telegram." }
                            telegramBusy = false; busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) { Text("Verificar conexión") }
            }
            if (telegramBusy) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Consultando Telegram…")
                }
            }
            telegramReport?.let { report ->
                HorizontalDivider()
                Text(if (report.connected) "✓ Telegram conectado" else "✗ Telegram no conectado")
                Text(if (report.channelFound) "✓ Canal encontrado: ${report.channelTitle ?: telegramChatId}" else "✗ Canal no encontrado")
                Text(if (report.canPublish) "✓ Permiso para publicar" else "✗ Sin permiso para publicar")
                Text(report.detail, style = MaterialTheme.typography.bodySmall)
            }
            Text("La verificación es no destructiva: no publica ni elimina mensajes.", style = MaterialTheme.typography.labelSmall)
        }

        SettingsCard("Apariencia", Icons.Default.Palette) {
            Text("Tema")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = preferences.themeMode == mode,
                        onClick = { onPreferencesChanged(preferences.copy(themeMode = mode), false) },
                        label = { Text(when (mode) { ThemeMode.SYSTEM -> "Sistema"; ThemeMode.DARK -> "Oscuro"; ThemeMode.LIGHT -> "Claro" }) }
                    )
                }
            }
            TextButton(onClick = { advanced = !advanced }) {
                Icon(if (advanced) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                Text(if (advanced) "Ocultar opciones avanzadas" else "Opciones avanzadas")
            }
            if (advanced) {
                SettingSwitch("Reproducir tráileres de fondo", preferences.autoplayTrailers) { onPreferencesChanged(preferences.copy(autoplayTrailers = it), false) }
                SettingSwitch("Mostrar anime", preferences.showAnime) { onPreferencesChanged(preferences.copy(showAnime = it), false) }
                SettingSwitch("Mostrar películas", preferences.showMovies) { onPreferencesChanged(preferences.copy(showMovies = it), false) }
                SettingSwitch("Mostrar series", preferences.showSeries) { onPreferencesChanged(preferences.copy(showSeries = it), false) }
                Text("Orden predeterminado", modifier = Modifier.padding(top = 8.dp))
                SortMode.entries.forEach { mode ->
                    RadioButtonRow(
                        label = when (mode) { SortMode.TITLE -> "Título"; SortMode.RECENT -> "Agregados recientemente"; SortMode.YEAR -> "Año"; SortMode.LAST_VIEWED -> "Último visto" },
                        selected = preferences.sortMode == mode,
                        onClick = { onPreferencesChanged(preferences.copy(sortMode = mode), false) }
                    )
                }
            }
        }

        if (advanced) SettingsCard("Progreso y apertura externa", Icons.Default.PlayCircle) {
            Text(if (TelegramLauncher.isInstalled(context)) "Telegram detectado" else "Telegram no detectado: se usará el navegador")
            SettingSwitch("Abrir contenido con Telegram", preferences.openWithTelegram) { onPreferencesChanged(preferences.copy(openWithTelegram = it), false) }
            SettingSwitch("Recordar episodios abiertos", preferences.rememberOpenedEpisodes) { onPreferencesChanged(preferences.copy(rememberOpenedEpisodes = it), false) }
            SettingSwitch("Marcar como visto al abrir", preferences.markWatchedOnOpen) { onPreferencesChanged(preferences.copy(markWatchedOnOpen = it), false) }
            if (preferences.markWatchedOnOpen) SettingSwitch("Confirmar antes de marcar", preferences.confirmMarkWatched) { onPreferencesChanged(preferences.copy(confirmMarkWatched = it), false) }
        }

        SettingsCard("Almacenamiento", Icons.Default.CleaningServices) {
            Text("Caché de imágenes: ${formatBytes(imageBytes)}")
            Text("Metadatos almacenados: ${formatBytes(metadataBytes)}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onClearImages(); imageBytes = 0; message = "Caché de imágenes borrada." }, modifier = Modifier.weight(1f)) { Text("Borrar imágenes") }
                OutlinedButton(onClick = { onClearMetadata(); metadataBytes = 0; message = "Metadatos almacenados borrados." }, modifier = Modifier.weight(1f)) { Text("Borrar metadatos") }
            }
            Text("Estas acciones no borran catálogo, favoritos, progreso ni configuración.", style = MaterialTheme.typography.labelSmall)
        }

        SettingsCard("Herramientas", Icons.Default.Build) {
            ListItem(headlineContent = { Text("Diagnóstico") }, supportingContent = { Text("Probar servicios y consultar errores") }, leadingContent = { Icon(Icons.Default.MonitorHeart, null) }, modifier = Modifier.fillMaxWidth().clickableNoRipple(onDiagnostics))
            ListItem(headlineContent = { Text("Acerca de") }, supportingContent = { Text("Versión y datos del proyecto") }, leadingContent = { Icon(Icons.Default.Info, null) }, modifier = Modifier.fillMaxWidth().clickableNoRipple(onAbout))
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(top = 14.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(8.dp)); Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            content()
        }
    }
}

@Composable
private fun SnapshotSummary(snapshot: CatalogSnapshot?) {
    if (snapshot == null) return
    HorizontalDivider()
    Text("${snapshot.items.size} títulos cargados • schema ${snapshot.schemaVersion}")
    Text("Última carga: ${DateFormat.getDateTimeInstance().format(Date(snapshot.loadedAtMillis))}", style = MaterialTheme.typography.labelMedium)
    if (snapshot.issues.isNotEmpty()) Text("${snapshot.issues.size} entradas con errores (ver Diagnóstico)", color = MaterialTheme.colorScheme.error)
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, modifier = Modifier.weight(1f)); Switch(checked, onChecked) }
}

@Composable
private fun RadioButtonRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickableNoRipple(onClick), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected, onClick); Text(label) }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.clickable(onClick = onClick)

@Composable
fun DiagnosticsScreen(
    preferences: AppPreferences,
    snapshot: CatalogSnapshot?,
    services: ServiceStatus,
    errors: List<String>,
    onBack: () -> Unit,
    onTest: () -> Unit,
    onClearErrors: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        HeaderWithBack("Diagnóstico", onBack)
        Card(Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                DiagnosticRow("Fuente activa", if (preferences.source == CatalogSource.REMOTE) "Remoto" else "Archivo local")
                DiagnosticRow("Origen", if (preferences.source == CatalogSource.REMOTE) preferences.remoteUrl else preferences.localFileName ?: "Sin archivo")
                DiagnosticRow("Acceso al catálogo", services.catalog)
                DiagnosticRow("TMDB", services.tmdb)
                DiagnosticRow("AniList", services.anilist)
                DiagnosticRow("Telegram", services.telegram)
                DiagnosticRow("Schema", snapshot?.schemaVersion ?: "Sin cargar")
                DiagnosticRow("Elementos válidos", snapshot?.items?.size?.toString() ?: "0")
                DiagnosticRow("Entradas inválidas", snapshot?.issues?.size?.toString() ?: "0")
                DiagnosticRow("Versión de la app", BuildConfig.VERSION_NAME)
                Button(onClick = onTest, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.NetworkCheck, null); Spacer(Modifier.width(8.dp)); Text("Probar servicios") }
            }
        }
        Text("Errores del catálogo actual", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp))
        snapshot?.issues?.forEach { Text("Entrada ${it.index + 1}${it.itemId?.let { id -> " ($id)" } ?: ""}: ${it.message}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp)) }
        Text("Errores recientes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp))
        if (errors.isEmpty()) Text("No hay errores registrados.") else errors.forEach { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp)) }
        if (errors.isNotEmpty()) TextButton(onClick = onClearErrors) { Text("Limpiar registro") }
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) { Text(label, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(.42f)); Text(value, modifier = Modifier.weight(.58f)) }
}

@Composable
fun AboutScreen(snapshot: CatalogSnapshot?, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderWithBack("Acerca de", onBack)
        Text("Mi Videoteca", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 28.dp))
        Text("Versión ${BuildConfig.VERSION_NAME}", modifier = Modifier.padding(top = 8.dp))
        Text("Catálogo activo: schema ${snapshot?.schemaVersion ?: "sin cargar"}")
        Text("Catálogo personal para organizar contenido audiovisual. Administración permite crear una publicación nueva de película únicamente después de una confirmación explícita; no modifica ni elimina mensajes existentes.", modifier = Modifier.padding(top = 20.dp))
    }
}

@Composable
fun HeaderWithBack(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") }; Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
}
