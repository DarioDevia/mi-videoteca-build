package com.mivideoteca.app.data

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.security.MessageDigest

class TelegramPublisherRepository(private val store: AppStore) {
    private val client = NetworkClient.http

    suspend fun verifyConnection(token: String?, chatId: String): TelegramConnectionReport = withContext(Dispatchers.IO) {
        require(!token.isNullOrBlank()) { "Guardá primero el Bot Token de Telegram." }
        require(chatId.trim().isNotBlank()) { "Ingresá el ID o @usuario del canal de películas." }
        var connected = false
        var channelFound = false
        var knownTitle: String? = null
        try {
            val me = call(token, "getMe")
            connected = true
            val botId = me.getAsJsonObject("result")?.longOrNull("id")
                ?: throw IllegalStateException("Telegram no devolvió la identidad del bot.")
            val chat = call(token, "getChat", mapOf("chat_id" to chatId.trim())).getAsJsonObject("result")
                ?: throw IllegalStateException("Telegram no devolvió los datos del canal.")
            channelFound = true
            knownTitle = chat.stringOrNull("title") ?: chat.stringOrNull("username")?.let { "@$it" }
            if (chat.stringOrNull("type") != "channel") {
                return@withContext TelegramConnectionReport(true, true, false, knownTitle, "El destino existe, pero no es un canal de Telegram.")
            }
            val membership = call(token, "getChatMember", mapOf("chat_id" to chatId.trim(), "user_id" to botId.toString()))
                .getAsJsonObject("result") ?: throw IllegalStateException("No se pudo consultar el permiso del bot.")
            val status = membership.stringOrNull("status")
            val canPublish = status == "creator" || (status == "administrator" && membership.booleanOrFalse("can_post_messages"))
            TelegramConnectionReport(
                connected = true,
                channelFound = true,
                canPublish = canPublish,
                channelTitle = knownTitle,
                detail = if (canPublish) "Telegram conectado. Canal encontrado y permiso para publicar confirmado."
                else "El canal fue encontrado, pero el bot no tiene permiso para publicar. Agregalo como administrador con permiso para publicar mensajes."
            )
        } catch (error: Throwable) {
            TelegramConnectionReport(connected, channelFound, false, knownTitle, friendlyError(error))
        }
    }

    suspend fun publishMovie(
        token: String?,
        chatId: String,
        profileId: String,
        draft: MoviePublicationDraft,
        caption: String,
        onStage: (PublishStage) -> Unit = {}
    ): TelegramPublishResult = withContext(Dispatchers.IO) {
        require(!token.isNullOrBlank()) { "Falta configurar el Bot Token de Telegram." }
        require(chatId.trim().isNotBlank()) { "Falta configurar el canal de películas." }
        require(draft.title.isNotBlank()) { "La publicación necesita un título." }
        require(!draft.posterUrl.isNullOrBlank()) { "La película no tiene una carátula disponible para publicar." }
        require(caption.isNotBlank()) { "La descripción no puede estar vacía." }
        require(caption.length <= PublicationFormatter.TELEGRAM_PHOTO_CAPTION_LIMIT) {
            "La descripción tiene ${caption.length} caracteres; Telegram admite ${PublicationFormatter.TELEGRAM_PHOTO_CAPTION_LIMIT} en una foto."
        }
        try {
            onStage(PublishStage.PREPARING)
            val poster = downloadPoster(draft.posterUrl)
            onStage(PublishStage.CONNECTING)
            val verification = verifyConnection(token, chatId)
            if (!verification.canPublish) throw IllegalStateException(verification.detail)
            onStage(PublishStage.PUBLISHING)
            val multipart = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", chatId.trim())
                .addFormDataPart("caption", caption)
                .addFormDataPart("photo", "poster.jpg", poster.bytes.toRequestBody(poster.contentType.toMediaTypeOrNull()))
                .build()
            val response = telegramRequest(token, "sendPhoto", multipart)
            onStage(PublishStage.VERIFYING)
            val messageId = response.getAsJsonObject("result")?.longOrNull("message_id")
                ?: throw IllegalStateException("Telegram respondió sin confirmar el identificador de la publicación.")
            TelegramPublishResult(messageId, verification.channelTitle, chatId.trim())
        } catch (error: Throwable) {
            store.logAdministrationError(profileId, "Publicación Telegram: ${friendlyError(error)}")
            throw IllegalStateException(friendlyError(error), error)
        }
    }

    fun receipt(draft: MoviePublicationDraft, caption: String, result: TelegramPublishResult): PublicationReceipt {
        val digest = MessageDigest.getInstance("SHA-256").digest(caption.toByteArray())
            .joinToString("") { "%02x".format(it) }
        return PublicationReceipt(draft.tmdbId, result.chatId, result.channelTitle, result.messageId,
            System.currentTimeMillis(), draft.posterUrl.orEmpty(), digest)
    }

    private fun call(token: String, method: String, fields: Map<String, String> = emptyMap()): JsonObject {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM).apply {
            fields.forEach { (key, value) -> addFormDataPart(key, value) }
        }.build()
        return telegramRequest(token, method, body)
    }

    private fun telegramRequest(token: String, method: String, body: okhttp3.RequestBody): JsonObject {
        val request = Request.Builder().url("https://api.telegram.org/bot$token/$method").post(body).build()
        return client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val json = runCatching { JsonParser.parseString(text).asJsonObject }.getOrNull()
            val ok = json?.get("ok")?.takeUnless { it.isJsonNull }?.asBoolean == true
            if (!response.isSuccessful || !ok) {
                val description = json?.stringOrNull("description")
                throw TelegramApiException(response.code, description)
            }
            json ?: throw IllegalStateException("Telegram devolvió una respuesta inesperada.")
        }
    }

    private fun downloadPoster(url: String): PosterBytes {
        val request = Request.Builder().url(url).header("Accept", "image/*").build()
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("No se pudo descargar la carátula (${response.code}).")
            val body = response.body ?: throw IllegalStateException("La carátula descargada está vacía.")
            val length = body.contentLength()
            if (length > MAX_PHOTO_BYTES) throw IllegalStateException("La carátula supera el límite de 10 MB de Telegram.")
            val type = body.contentType()?.toString()?.takeIf { it.startsWith("image/") }
                ?: throw IllegalStateException("La dirección de la carátula no devolvió una imagen.")
            val bytes = body.bytes()
            if (bytes.isEmpty() || bytes.size > MAX_PHOTO_BYTES) throw IllegalStateException("La carátula no tiene un tamaño válido para Telegram.")
            PosterBytes(bytes, type)
        }
    }

    private fun friendlyError(error: Throwable): String = when (error) {
        is TelegramApiException -> when (error.code) {
            401 -> "El Bot Token no es válido."
            403 -> "Telegram rechazó la operación: el bot no pertenece al canal o no tiene permiso para publicar."
            400 -> when {
                error.description?.contains("chat not found", true) == true -> "No se encontró el canal configurado. Revisá su ID y que el bot esté agregado."
                error.description?.contains("caption is too long", true) == true -> "La descripción supera el límite permitido por Telegram."
                else -> error.description ?: "Telegram rechazó los datos enviados."
            }
            429 -> "Telegram recibió demasiadas solicitudes. Esperá unos instantes antes de intentar nuevamente."
            else -> error.description ?: "Telegram respondió con un error (${error.code})."
        }
        is SocketTimeoutException -> "Telegram tardó demasiado en responder. Comprobá la conexión e intentá nuevamente."
        is IOException -> "No se pudo conectar. Comprobá tu conexión a Internet."
        else -> error.message ?: "Ocurrió un error inesperado."
    }

    private fun JsonObject.stringOrNull(name: String): String? = get(name)?.takeUnless { it.isJsonNull }?.asString
    private fun JsonObject.longOrNull(name: String): Long? = runCatching { get(name)?.takeUnless { it.isJsonNull }?.asLong }.getOrNull()
    private fun JsonObject.booleanOrFalse(name: String): Boolean = runCatching { get(name)?.asBoolean == true }.getOrDefault(false)

    private data class PosterBytes(val bytes: ByteArray, val contentType: String)
    private class TelegramApiException(val code: Int, val description: String?) : IOException()

    private companion object { const val MAX_PHOTO_BYTES = 10 * 1024 * 1024 }
}
