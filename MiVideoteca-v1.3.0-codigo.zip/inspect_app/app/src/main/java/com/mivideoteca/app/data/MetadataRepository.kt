package com.mivideoteca.app.data

import android.text.Html
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.net.URLEncoder
import java.util.Locale

class MetadataRepository(private val store: AppStore) {
    private val gson = Gson()
    private val client = NetworkClient.http

    suspend fun searchMovies(query: String, preferences: AppPreferences): List<TmdbMovieSearchResult> = withContext(Dispatchers.IO) {
        require(preferences.tmdbToken.isNotBlank()) { "Configurá primero el token de lectura de TMDB." }
        require(query.trim().length >= 2) { "Escribí al menos dos caracteres para buscar." }
        val url = "https://api.themoviedb.org/3/search/movie".toHttpUrl().newBuilder()
            .addQueryParameter("query", query.trim())
            .addQueryParameter("language", preferences.metadataLanguage)
            .addQueryParameter("include_adult", "false")
            .build()
        val json = tmdbObject(url.toString(), preferences.tmdbToken)
        json.getAsJsonArray("results")?.mapNotNull { element ->
            val movie = element.asJsonObject
            val id = movie.longOrNull("id") ?: return@mapNotNull null
            val title = movie.stringOrNull("title")?.takeIf(String::isNotBlank) ?: return@mapNotNull null
            TmdbMovieSearchResult(
                id = id,
                title = title,
                originalTitle = movie.stringOrNull("original_title"),
                releaseDate = movie.stringOrNull("release_date"),
                posterUrl = movie.stringOrNull("poster_path")?.let { "https://image.tmdb.org/t/p/w342$it" }
            )
        }.orEmpty()
    }

    suspend fun searchCatalogEntries(
        query: String,
        type: AdminContentType,
        preferences: AppPreferences
    ): List<AdminSearchResult> = withContext(Dispatchers.IO) {
        require(query.trim().length >= 2) { "Escribí al menos dos caracteres para buscar." }
        when (type) {
            AdminContentType.MOVIE, AdminContentType.SERIES -> {
                require(preferences.tmdbToken.isNotBlank()) { "Configurá primero el token de lectura de TMDB." }
                val kind = if (type == AdminContentType.MOVIE) "movie" else "tv"
                val json = tmdbObject(
                    "https://api.themoviedb.org/3/search/$kind".toHttpUrl().newBuilder()
                        .addQueryParameter("query", query.trim())
                        .addQueryParameter("language", preferences.metadataLanguage)
                        .addQueryParameter("include_adult", "false")
                        .build().toString(),
                    preferences.tmdbToken
                )
                json.getAsJsonArray("results")?.mapNotNull { element ->
                    val value = element.asJsonObject
                    val id = value.longOrNull("id") ?: return@mapNotNull null
                    val title = value.stringOrNull(if (kind == "movie") "title" else "name")
                        ?.takeIf(String::isNotBlank) ?: return@mapNotNull null
                    AdminSearchResult(
                        id = id,
                        contentType = type,
                        title = title,
                        originalTitle = value.stringOrNull(if (kind == "movie") "original_title" else "original_name"),
                        releaseDate = value.stringOrNull(if (kind == "movie") "release_date" else "first_air_date"),
                        posterUrl = value.stringOrNull("poster_path")?.let { "https://image.tmdb.org/t/p/w342$it" }
                    )
                }.orEmpty()
            }
            AdminContentType.ANIME -> searchAnime(query)
        }
    }

    suspend fun loadCatalogEntryDraft(
        result: AdminSearchResult,
        preferences: AppPreferences
    ): CatalogEntryDraft = withContext(Dispatchers.IO) {
        when (result.contentType) {
            AdminContentType.MOVIE, AdminContentType.SERIES -> loadTmdbCatalogEntry(result, preferences)
            AdminContentType.ANIME -> loadAniListCatalogEntry(result.id)
        }
    }

    suspend fun loadMoviePublicationDraft(movieId: Long, preferences: AppPreferences): MoviePublicationDraft = withContext(Dispatchers.IO) {
        require(preferences.tmdbToken.isNotBlank()) { "Configurá primero el token de lectura de TMDB." }
        val primaryLanguage = preferences.metadataLanguage.takeIf { it.startsWith("es", true) } ?: "es-MX"
        val url = "https://api.themoviedb.org/3/movie/$movieId".toHttpUrl().newBuilder()
            .addQueryParameter("language", primaryLanguage)
            .addQueryParameter("append_to_response", "credits,translations,alternative_titles,videos")
            .build()
        val json = tmdbObject(url.toString(), preferences.tmdbToken)
        val title = json.stringOrNull("title")?.takeIf(String::isNotBlank)
            ?: throw IllegalStateException("TMDB no devolvió un título válido.")
        val originalTitle = json.stringOrNull("original_title")
        val latinTitle = localizedLatinTitle(json, title, originalTitle)
        var synopsis = json.stringOrNull("overview")?.takeIf(String::isNotBlank)
        if (synopsis.isNullOrBlank() && primaryLanguage != "es-ES") {
            val fallbackUrl = "https://api.themoviedb.org/3/movie/$movieId".toHttpUrl().newBuilder()
                .addQueryParameter("language", "es-ES").build()
            synopsis = runCatching { tmdbObject(fallbackUrl.toString(), preferences.tmdbToken).stringOrNull("overview") }
                .getOrNull()?.takeIf(String::isNotBlank)
        }
        val credits = json.getAsJsonObject("credits")
        val cast = credits?.getAsJsonArray("cast")?.mapNotNull { it.asJsonObject.stringOrNull("name") }
            ?.distinct()?.take(12).orEmpty()
        val directors = credits?.getAsJsonArray("crew")?.mapNotNull {
            it.asJsonObject.takeIf { crew -> crew.stringOrNull("job") == "Director" }?.stringOrNull("name")
        }?.distinct().orEmpty()
        val countries = json.getAsJsonArray("production_countries")?.mapNotNull { element ->
            val country = element.asJsonObject
            val code = country.stringOrNull("iso_3166_1")?.uppercase()?.takeIf { it.length == 2 } ?: return@mapNotNull null
            val localized = Locale("", code).getDisplayCountry(Locale("es")).takeIf(String::isNotBlank)
                ?: country.stringOrNull("name") ?: code
            ProductionCountry(code, localized.replaceFirstChar { it.titlecase(Locale("es")) }, PublicationFormatter.countryFlag(code))
        }.orEmpty()
        val alternativeTitles = buildList {
            json.getAsJsonObject("alternative_titles")?.getAsJsonArray("titles")?.forEach {
                it.asJsonObject.stringOrNull("title")?.takeIf(String::isNotBlank)?.let(::add)
            }
            json.getAsJsonObject("translations")?.getAsJsonArray("translations")?.forEach {
                it.asJsonObject.getAsJsonObject("data")?.stringOrNull("title")?.takeIf(String::isNotBlank)?.let(::add)
            }
        }.distinct()
        val releaseDate = json.stringOrNull("release_date")
        val draft = MoviePublicationDraft(
            tmdbId = movieId,
            title = title,
            originalTitle = originalTitle,
            latinTitle = latinTitle,
            alternativeTitles = alternativeTitles,
            year = releaseDate?.take(4)?.takeIf { it.all(Char::isDigit) },
            releaseDate = releaseDate,
            posterUrl = json.stringOrNull("poster_path")?.let { "https://image.tmdb.org/t/p/w780$it" },
            backdropUrl = json.stringOrNull("backdrop_path")?.let { "https://image.tmdb.org/t/p/w1280$it" },
            synopsis = synopsis,
            genres = json.getAsJsonArray("genres")?.mapNotNull { it.asJsonObject.stringOrNull("name") }.orEmpty(),
            runtimeMinutes = json.intOrNull("runtime"),
            cast = cast,
            directors = directors,
            countries = countries,
            caption = "",
            trailerUrl = youtubeTrailerUrl(json.getAsJsonObject("videos"))
        )
        draft.copy(caption = PublicationFormatter.movieCaption(title, draft.year, latinTitle, synopsis, cast, directors, countries))
    }

    suspend fun enrich(item: VideoItem, preferences: AppPreferences): VideoItem = withContext(Dispatchers.IO) {
        val cache = cacheFile(preferences.profileId, item.id)
        if (cache.exists() && System.currentTimeMillis() - cache.lastModified() < 30L * 24 * 60 * 60 * 1000) {
            runCatching { return@withContext gson.fromJson(cache.readText(), VideoItem::class.java) }
        }
        val enriched = runCatching {
            when {
                item.tipo == "anime" && item.anilistId != null -> fromAniList(item)
                item.tipo in setOf("pelicula", "serie") && item.tmdbId != null && preferences.tmdbToken.isNotBlank() -> fromTmdb(item, preferences)
                else -> item
            }
        }.getOrDefault(item)
        runCatching { cache.parentFile?.mkdirs(); cache.writeText(gson.toJson(enriched)) }
        enriched
    }

    private fun fromTmdb(item: VideoItem, preferences: AppPreferences): VideoItem {
        val kind = if (item.tipo == "serie") "tv" else "movie"
        val language = URLEncoder.encode(preferences.metadataLanguage, "UTF-8")
        val request = Request.Builder()
            .url("https://api.themoviedb.org/3/$kind/${item.tmdbId}?language=$language&append_to_response=videos")
            .header("Authorization", "Bearer ${preferences.tmdbToken}")
            .build()
        val json = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return item
            JsonParser.parseString(response.body?.string() ?: return item).asJsonObject
        }
        val title = if (kind == "movie") json.get("title")?.asString else json.get("name")?.asString
        val original = if (kind == "movie") json.get("original_title")?.asString else json.get("original_name")?.asString
        val date = if (kind == "movie") json.get("release_date")?.asString else json.get("first_air_date")?.asString
        val genres = json.getAsJsonArray("genres")?.mapNotNull { it.asJsonObject.get("name")?.asString }.orEmpty()
        return item.copy(
            titulo = item.titulo.ifBlank { title ?: item.titulo },
            tituloOriginal = item.tituloOriginal ?: original,
            year = item.year ?: date?.take(4)?.toIntOrNull(),
            generos = item.generos.ifEmpty { genres },
            sinopsis = item.sinopsis?.takeIf { it.isNotBlank() } ?: json.get("overview")?.asString,
            posterUrl = item.posterUrl ?: json.get("poster_path")?.asString?.let { "https://image.tmdb.org/t/p/w500$it" },
            backdropUrl = item.backdropUrl ?: json.get("backdrop_path")?.asString?.let { "https://image.tmdb.org/t/p/w1280$it" },
            trailerUrl = item.trailerUrl ?: youtubeTrailerUrl(json.getAsJsonObject("videos"))
        )
    }

    private fun fromAniList(item: VideoItem): VideoItem {
        val body = """{"query":"query (${ '$' }id: Int) { Media(id: ${ '$' }id, type: ANIME) { title { romaji english native } description genres episodes duration coverImage { extraLarge } bannerImage trailer { id site thumbnail } startDate { year } } }","variables":{"id":${item.anilistId}}}"""
        val request = Request.Builder().url("https://graphql.anilist.co")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        val media = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return item
            JsonParser.parseString(response.body?.string() ?: return item).asJsonObject
                .getAsJsonObject("data")?.getAsJsonObject("Media") ?: return item
        }
        val title = media.getAsJsonObject("title")
        val description = media.get("description")?.takeUnless { it.isJsonNull }?.asString?.let {
            Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString().trim()
        }
        return item.copy(
            tituloOriginal = item.tituloOriginal ?: title?.get("romaji")?.takeUnless { it.isJsonNull }?.asString,
            titulosAlternativos = item.titulosAlternativos.ifEmpty {
                listOfNotNull(title?.get("english")?.takeUnless { it.isJsonNull }?.asString, title?.get("native")?.takeUnless { it.isJsonNull }?.asString)
            },
            year = item.year ?: media.getAsJsonObject("startDate")?.get("year")?.takeUnless { it.isJsonNull }?.asInt,
            generos = item.generos.ifEmpty { media.getAsJsonArray("genres")?.map { it.asString }.orEmpty() },
            sinopsis = item.sinopsis?.takeIf { it.isNotBlank() } ?: description,
            posterUrl = item.posterUrl ?: media.getAsJsonObject("coverImage")?.get("extraLarge")?.asString,
            backdropUrl = item.backdropUrl ?: media.get("bannerImage")?.takeUnless { it.isJsonNull }?.asString,
            duracion = item.duracion ?: media.get("duration")?.takeUnless { it.isJsonNull }?.asInt?.let { "$it min" },
            trailerUrl = item.trailerUrl ?: media.objectOrNull("trailer")?.takeIf { it.stringOrNull("site").equals("youtube", true) }
                ?.stringOrNull("id")?.let { "https://www.youtube.com/watch?v=$it" }
        )
    }

    private fun searchAnime(query: String): List<AdminSearchResult> {
        val escaped = gson.toJson(query.trim())
        val body = """{"query":"query (${ '$' }search: String) { Page(page: 1, perPage: 20) { media(search: ${ '$' }search, type: ANIME, sort: SEARCH_MATCH) { id title { romaji english native } startDate { year month day } coverImage { large } } } }","variables":{"search":$escaped}}"""
        val request = Request.Builder().url("https://graphql.anilist.co")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("AniList respondió con un error (${response.code}).")
            val root = JsonParser.parseString(response.body?.string().orEmpty()).asJsonObject
            root.getAsJsonObject("data")?.getAsJsonObject("Page")?.getAsJsonArray("media")?.mapNotNull { element ->
                val media = element.asJsonObject
                val id = media.longOrNull("id") ?: return@mapNotNull null
                val titles = media.getAsJsonObject("title")
                val title = titles?.stringOrNull("english") ?: titles?.stringOrNull("romaji") ?: return@mapNotNull null
                val date = media.getAsJsonObject("startDate")?.let { d ->
                    d.intOrNull("year")?.let { year -> "%04d-%02d-%02d".format(year, d.intOrNull("month") ?: 1, d.intOrNull("day") ?: 1) }
                }
                AdminSearchResult(id, AdminContentType.ANIME, title, titles?.stringOrNull("romaji"), date,
                    media.getAsJsonObject("coverImage")?.stringOrNull("large"))
            }.orEmpty()
        }
    }

    private fun loadTmdbCatalogEntry(result: AdminSearchResult, preferences: AppPreferences): CatalogEntryDraft {
        val kind = if (result.contentType == AdminContentType.MOVIE) "movie" else "tv"
        val json = tmdbObject(
            "https://api.themoviedb.org/3/$kind/${result.id}".toHttpUrl().newBuilder()
                .addQueryParameter("language", preferences.metadataLanguage)
                .addQueryParameter("append_to_response", "videos,alternative_titles")
                .build().toString(),
            preferences.tmdbToken
        )
        val titleKey = if (kind == "movie") "title" else "name"
        val originalKey = if (kind == "movie") "original_title" else "original_name"
        val dateKey = if (kind == "movie") "release_date" else "first_air_date"
        val alternatives = json.getAsJsonObject("alternative_titles")?.let { alt ->
            (alt.getAsJsonArray("titles") ?: alt.getAsJsonArray("results"))?.mapNotNull {
                it.asJsonObject.stringOrNull(if (kind == "movie") "title" else "name")
            }
        }.orEmpty().distinct()
        val duration = if (kind == "movie") json.intOrNull("runtime")?.let { "$it min" }
            else json.getAsJsonArray("episode_run_time")?.firstOrNull()?.asInt?.let { "$it min por episodio" }
        return CatalogEntryDraft(
            sourceId = result.id,
            contentType = result.contentType,
            title = json.stringOrNull(titleKey) ?: result.title,
            originalTitle = json.stringOrNull(originalKey),
            alternativeTitles = alternatives,
            year = json.stringOrNull(dateKey)?.take(4)?.toIntOrNull(),
            synopsis = json.stringOrNull("overview")?.takeIf(String::isNotBlank),
            genres = json.getAsJsonArray("genres")?.mapNotNull { it.asJsonObject.stringOrNull("name") }.orEmpty(),
            duration = duration,
            posterUrl = json.stringOrNull("poster_path")?.let { "https://image.tmdb.org/t/p/w780$it" },
            backdropUrl = json.stringOrNull("backdrop_path")?.let { "https://image.tmdb.org/t/p/w1280$it" },
            trailerUrl = youtubeTrailerUrl(json.getAsJsonObject("videos"))
        )
    }

    private fun loadAniListCatalogEntry(id: Long): CatalogEntryDraft {
        val body = """{"query":"query (${ '$' }id: Int) { Media(id: ${ '$' }id, type: ANIME) { id title { romaji english native } description genres episodes duration coverImage { extraLarge } bannerImage trailer { id site } startDate { year } } }","variables":{"id":$id}}"""
        val request = Request.Builder().url("https://graphql.anilist.co")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        val media = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("AniList respondió con un error (${response.code}).")
            JsonParser.parseString(response.body?.string().orEmpty()).asJsonObject
                .getAsJsonObject("data")?.getAsJsonObject("Media")
                ?: throw IllegalStateException("AniList no devolvió la ficha seleccionada.")
        }
        val titles = media.getAsJsonObject("title")
        val title = titles?.stringOrNull("english") ?: titles?.stringOrNull("romaji")
            ?: throw IllegalStateException("AniList no devolvió un título válido.")
        val description = media.stringOrNull("description")?.let { Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString().trim() }
        return CatalogEntryDraft(
            sourceId = id,
            contentType = AdminContentType.ANIME,
            title = title,
            originalTitle = titles?.stringOrNull("romaji"),
            alternativeTitles = listOfNotNull(titles?.stringOrNull("native")).distinct(),
            year = media.getAsJsonObject("startDate")?.intOrNull("year"),
            synopsis = description,
            genres = media.getAsJsonArray("genres")?.map { it.asString }.orEmpty(),
            duration = media.intOrNull("duration")?.let { "$it min por episodio" },
            posterUrl = media.getAsJsonObject("coverImage")?.stringOrNull("extraLarge"),
            backdropUrl = media.stringOrNull("bannerImage"),
            trailerUrl = media.objectOrNull("trailer")?.takeIf { it.stringOrNull("site").equals("youtube", true) }
                ?.stringOrNull("id")?.let { "https://www.youtube.com/watch?v=$it" }
        )
    }

    private fun youtubeTrailerUrl(videos: JsonObject?): String? {
        val results = videos?.getAsJsonArray("results") ?: return null
        val video = results.map { it.asJsonObject }.firstOrNull {
            it.stringOrNull("site").equals("YouTube", true) &&
                it.stringOrNull("type").equals("Trailer", true) && it.get("official")?.asBoolean != false
        } ?: results.map { it.asJsonObject }.firstOrNull { it.stringOrNull("site").equals("YouTube", true) }
        return video?.stringOrNull("key")?.let { "https://www.youtube.com/watch?v=$it" }
    }

    private fun cacheFile(profileId: String, itemId: String): File {
        val safe = itemId.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return File(store.profileDir(profileId), "metadata/v2/$safe.json")
    }

    private fun tmdbObject(url: String, token: String): JsonObject {
        val request = Request.Builder().url(url).header("Authorization", "Bearer $token").build()
        return client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JsonParser.parseString(body).asJsonObject.stringOrNull("status_message") }.getOrNull()
                throw IllegalStateException(when (response.code) {
                    401 -> "El token de TMDB no es válido."
                    429 -> "TMDB recibió demasiadas solicitudes. Intentá nuevamente en unos minutos."
                    else -> detail ?: "TMDB respondió con un error (${response.code})."
                })
            }
            runCatching { JsonParser.parseString(body).asJsonObject }
                .getOrElse { throw IllegalStateException("TMDB devolvió una respuesta inesperada.") }
        }
    }

    private fun localizedLatinTitle(json: JsonObject, title: String, originalTitle: String?): String? {
        val latinCountries = listOf("AR", "MX", "CO", "CL", "PE", "UY", "VE", "EC", "BO", "PY", "CR", "GT", "DO", "PA", "HN", "NI", "SV", "PR", "US")
        val translations = json.getAsJsonObject("translations")?.getAsJsonArray("translations")?.map { it }.orEmpty()
        latinCountries.forEach { country ->
            translations.firstOrNull {
                val item = it.asJsonObject
                item.stringOrNull("iso_639_1") == "es" && item.stringOrNull("iso_3166_1") == country
            }?.asJsonObject?.getAsJsonObject("data")?.stringOrNull("title")
                ?.takeIf { it.isNotBlank() && !it.equals(originalTitle, true) }?.let { return it }
        }
        val alternatives = json.getAsJsonObject("alternative_titles")?.getAsJsonArray("titles")?.map { it }.orEmpty()
        latinCountries.forEach { country ->
            alternatives.firstOrNull { it.asJsonObject.stringOrNull("iso_3166_1") == country }
                ?.asJsonObject?.stringOrNull("title")
                ?.takeIf { it.isNotBlank() && !it.equals(originalTitle, true) }?.let { return it }
        }
        return title.takeIf { it.isNotBlank() && !it.equals(originalTitle, true) }
    }

    private fun JsonObject.stringOrNull(name: String): String? = get(name)?.takeUnless { it.isJsonNull }?.asString
    private fun JsonObject.objectOrNull(name: String): JsonObject? = get(name)?.takeIf { it.isJsonObject }?.asJsonObject
    private fun JsonObject.longOrNull(name: String): Long? = runCatching { get(name)?.takeUnless { it.isJsonNull }?.asLong }.getOrNull()
    private fun JsonObject.intOrNull(name: String): Int? = runCatching { get(name)?.takeUnless { it.isJsonNull }?.asInt }.getOrNull()
}
