package com.mivideoteca.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mivideoteca.app.data.AppPreferences
import com.mivideoteca.app.data.VideoItem

@Composable
fun SearchScreen(items: List<VideoItem>, preferences: AppPreferences, onSelect: (VideoItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    val visible = remember(items, query, preferences) {
        items.filter { item ->
            val typeVisible = when (item.tipo) {
                "anime" -> preferences.showAnime
                "serie" -> preferences.showSeries
                "pelicula" -> preferences.showMovies
                else -> false
            }
            val haystack = buildList {
                add(item.titulo); item.tituloOriginal?.let(::add); addAll(item.titulosAlternativos)
                addAll(item.generos); item.year?.let { add(it.toString()) }
            }
            typeVisible && (query.isBlank() || haystack.any { it.contains(query.trim(), ignoreCase = true) })
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Buscar", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("Título, género o año") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
        )
        Text("${visible.size} resultados", style = MaterialTheme.typography.labelMedium)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(108.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
        ) {
            items(visible, key = { it.id }) { item -> Poster(item, Modifier.clickable { onSelect(item) }) }
        }
    }
}

@Composable
fun FavoritesScreen(items: List<VideoItem>, onSelect: (VideoItem) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Mi lista", style = MaterialTheme.typography.headlineSmall)
        if (items.isEmpty()) Text("Todavía no agregaste favoritos.", modifier = Modifier.padding(top = 24.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(108.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
        ) { items(items, key = { it.id }) { item -> Poster(item, Modifier.clickable { onSelect(item) }) } }
    }
}
