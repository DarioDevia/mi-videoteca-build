package com.mivideoteca.app.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.mivideoteca.app.data.ThemeMode

val Ink = Color(0xFF0B0D12)
val SurfaceDark = Color(0xFF151923)
val SurfaceRaised = Color(0xFF202633)
val Sky = Color(0xFF35A7D8)
val Coral = Color(0xFFFF6B5E)

private val darkColors = darkColorScheme(
    primary = Sky,
    secondary = Coral,
    background = Ink,
    surface = SurfaceDark,
    surfaceVariant = SurfaceRaised,
    onPrimary = Color.White,
    onBackground = Color(0xFFF4F5F7),
    onSurface = Color(0xFFF4F5F7)
)

private val lightColors = lightColorScheme(
    primary = Color(0xFF00658A),
    secondary = Color(0xFFA9342D),
    background = Color(0xFFF8F9FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFE8ECF2),
    onBackground = Color(0xFF171A20),
    onSurface = Color(0xFF171A20)
)

@Composable
fun MiVideotecaTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
        }
    }
    MaterialTheme(colorScheme = if (dark) darkColors else lightColors, content = content)
}
