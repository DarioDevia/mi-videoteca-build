package com.mivideoteca.app.ui.screens

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.SubcomposeAsyncImage
import com.mivideoteca.app.data.*
import com.mivideoteca.app.util.TelegramLauncher

@Composable
fun DetailScreen(
    item: VideoItem,
    progress: UserProgress?,
    favorite: Boolean,
    preferences: AppPreferences,
    onBack: () -> Unit,
    onToggleFavorite: (VideoItem) -> Unit,
    onOpen: (VideoItem, Episode?, Boolean) -> Unit
) {
    val context = LocalContext.current
    var selectedSeason by remember(item.id) { mutableIntStateOf(item.temporadas.firstOrNull()?.numero ?: 1) }
    var pendingEpisode by remember { mutableStateOf<Episode?>(null) }
    var pendingUrl by remember { mutableStateOf<String?>(null) }
    var showConfirmation by remember { mutableStateOf(false) }
    val season = item.temporadas.firstOrNull { it.numero == selectedSeason }
    val trailerKey = remember(item.trailerUrl) { youtubeKey(item.trailerUrl) }

    fun launch(episode: Episode?, watched: Boolean) {
        val url = episode?.telegramUrl ?: item.telegramUrl
        onOpen(item, episode, watched)
        if (!url.isNullOrBlank()) TelegramLauncher.open(context, url, preferences.openWithTelegram)
    }

    fun requestOpen(episode: Episode?) {
        val url = episode?.telegramUrl ?: item.telegramUrl
        if (url.isNullOrBlank()) return
        if (preferences.markWatchedOnOpen && preferences.confirmMarkWatched) {
            pendingEpisode = episode; pendingUrl = url; showConfirmation = true
        } else launch(episode, preferences.markWatchedOnOpen)
    }

    if (showConfirmation) {
        AlertDialog(
            onDismissRequest = { showConfirmation = false },
            title = { Text("¿Marcar como visto?") },
            text = { Text("Podés abrirlo sin marcarlo o registrarlo como visto.") },
            confirmButton = { TextButton(onClick = { showConfirmation = false; launch(pendingEpisode, true) }) { Text("Abrir y marcar") } },
            dismissButton = { TextButton(onClick = { showConfirmation = false; launch(pendingEpisode, false) }) { Text("Solo abrir") } }
        )
    }

    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        item {
            Box(Modifier.fillMaxWidth().height(285.dp)) {
                if (preferences.autoplayTrailers && trailerKey != null) TrailerBackground(trailerKey)
                else SubcomposeAsyncImage(
                        model = item.backdropUrl ?: item.posterUrl,
                        contentDescription = item.titulo,
                        contentScale = ContentScale.Crop,
                        loading = { Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant)) },
                        error = { Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant)) },
                        modifier = Modifier.fillMaxSize()
                    )
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.15f), MaterialTheme.colorScheme.background))))
                if (preferences.autoplayTrailers && trailerKey != null) {
                    Surface(color = Color.Black.copy(.62f), shape = RoundedCornerShape(6.dp), modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp)) {
                        Text("TRÁILER", color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }
                IconButton(onClick = onBack, modifier = Modifier.padding(8.dp).align(Alignment.TopStart)) {
                    Surface(shape = RoundedCornerShape(50), color = Color.Black.copy(.55f)) { Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White, modifier = Modifier.padding(8.dp)) }
                }
                IconButton(onClick = { onToggleFavorite(item) }, modifier = Modifier.padding(8.dp).align(Alignment.TopEnd)) {
                    Surface(shape = RoundedCornerShape(50), color = Color.Black.copy(.55f)) {
                        Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorito", tint = if (favorite) MaterialTheme.colorScheme.secondary else Color.White, modifier = Modifier.padding(8.dp))
                    }
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp)) {
                Text(item.titulo, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                item.tituloOriginal?.takeIf { it != item.titulo }?.let { Text(it, color = MaterialTheme.colorScheme.onSurface.copy(.65f)) }
                Text(
                    listOfNotNull(item.year?.toString(), item.generos.takeIf { it.isNotEmpty() }?.joinToString(" • "), item.calidad).joinToString("  |  "),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 8.dp)
                )
                Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { requestOpen(null) }, enabled = !item.telegramUrl.isNullOrBlank(), modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("VER EN TELEGRAM")
                    }
                    FilledTonalButton(onClick = { onOpen(item, null, true) }, enabled = progress?.watchedItem != true) {
                        Icon(Icons.Default.Check, null); Text(if (progress?.watchedItem == true) "Visto" else "Marcar")
                    }
                }
                if (!item.audio.isNullOrBlank() || !item.subtitulos.isNullOrBlank()) {
                    Text(listOfNotNull(item.audio?.let { "Audio: $it" }, item.subtitulos?.let { "Subtítulos: $it" }).joinToString("  •  "), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 12.dp))
                }
                item.sinopsis?.takeIf { it.isNotBlank() }?.let {
                    Text("Sinopsis", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 6.dp))
                    Text(it, color = MaterialTheme.colorScheme.onSurface.copy(.82f))
                }
            }
        }
        if (item.temporadas.isNotEmpty()) {
            item {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 20.dp)) {
                    Text("Episodios", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item.temporadas.forEach { s ->
                            FilterChip(selected = s.numero == selectedSeason, onClick = { selectedSeason = s.numero }, label = { Text(s.titulo ?: "Temporada ${s.numero}") })
                        }
                    }
                }
            }
            items(season?.episodios.orEmpty(), key = { it.id }) { episode ->
                val watched = episode.id in (progress?.watchedEpisodeIds ?: emptySet())
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { requestOpen(episode) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(width = 105.dp, height = 62.dp).clip(RoundedCornerShape(7.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                            if (episode.thumbnailUrl != null) SubcomposeAsyncImage(model = episode.thumbnailUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            else Icon(Icons.Default.PlayCircle, null)
                        }
                        Column(Modifier.padding(start = 12.dp).weight(1f)) {
                            Text("Episodio ${episode.numero}", fontWeight = FontWeight.Bold)
                            episode.titulo?.let { Text(it, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                            episode.duracion?.let { Text(it, style = MaterialTheme.typography.labelSmall) }
                        }
                        Icon(if (watched) Icons.Default.CheckCircle else Icons.Default.PlayArrow, if (watched) "Visto" else "Abrir", tint = if (watched) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(32.dp)) }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun TrailerBackground(youtubeKey: String) {
    var webView by remember { mutableStateOf<WebView?>(null) }
    DisposableEffect(youtubeKey) { onDispose { webView?.stopLoading(); webView?.destroy(); webView = null } }
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                webView = this
                setBackgroundColor(AndroidColor.BLACK)
                settings.javaScriptEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.loadsImagesAutomatically = true
                webChromeClient = WebChromeClient()
                val html = """
                    <html><head><meta name="viewport" content="width=device-width,initial-scale=1"/>
                    <style>html,body,iframe{margin:0;width:100%;height:100%;overflow:hidden;background:#000} iframe{border:0;transform:scale(1.25)}</style></head>
                    <body><iframe src="https://www.youtube-nocookie.com/embed/$youtubeKey?autoplay=1&mute=1&controls=0&loop=1&playlist=$youtubeKey&playsinline=1&rel=0" allow="autoplay; encrypted-media"></iframe></body></html>
                """.trimIndent()
                loadDataWithBaseURL("https://www.youtube-nocookie.com", html, "text/html", "UTF-8", null)
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}

private fun youtubeKey(url: String?): String? {
    if (url.isNullOrBlank()) return null
    val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return null
    val key = when {
        uri.host.equals("youtu.be", true) -> uri.lastPathSegment
        uri.host?.contains("youtube", true) == true -> uri.getQueryParameter("v") ?: uri.pathSegments.lastOrNull()
        else -> null
    }
    return key?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{6,20}")) }
}
