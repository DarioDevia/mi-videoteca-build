package com.mivideoteca.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.mivideoteca.app.data.*
import com.mivideoteca.app.security.SecureSecretStore
import com.mivideoteca.app.util.CatalogShareLauncher
import kotlinx.coroutines.launch

private enum class AdminStep { HOME, SEARCH, PREVIEW, ENTRY_PREVIEW, SUCCESS, CATALOG_SUCCESS, MANUAL_ITEMS }

@Composable
fun AdminScreen(
    preferences: AppPreferences,
    snapshot: CatalogSnapshot?,
    catalogRepository: CatalogRepository,
    metadataRepository: MetadataRepository,
    telegramRepository: TelegramPublisherRepository,
    secretStore: SecureSecretStore,
    store: AppStore,
    onCatalogChanged: (CatalogSnapshot) -> Unit
) {
    var step by remember { mutableStateOf(AdminStep.HOME) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<TmdbMovieSearchResult>>(emptyList()) }
    var adminType by remember { mutableStateOf(AdminContentType.MOVIE) }
    var entryResults by remember { mutableStateOf<List<AdminSearchResult>>(emptyList()) }
    var entryDraft by remember { mutableStateOf<CatalogEntryDraft?>(null) }
    var draft by remember { mutableStateOf<MoviePublicationDraft?>(null) }
    var caption by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var publishStage by remember { mutableStateOf<PublishStage?>(null) }
    var confirmPublish by remember { mutableStateOf(false) }
    var completed by remember { mutableStateOf<TelegramPublishResult?>(null) }
    var telegramUrl by remember { mutableStateOf("") }
    var duplicate by remember { mutableStateOf<VideoItem?>(null) }
    var entryDuplicate by remember { mutableStateOf<VideoItem?>(null) }
    var confirmCatalogPublish by remember { mutableStateOf(false) }
    var manualItems by remember(preferences.profileId) { mutableStateOf(catalogRepository.manualItems(preferences.profileId)) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null && snapshot != null) scope.launch {
            busy = true
            runCatching { catalogRepository.exportCatalog(snapshot, uri) }
                .onSuccess { message = "catalogo.json guardado correctamente." }
                .onFailure { message = it.message ?: "No se pudo guardar el catálogo." }
            busy = false
        }
    }

    fun saveMovieToCatalog(movie: MoviePublicationDraft, existing: VideoItem?) {
        if (busy) return
        scope.launch {
            busy = true; message = null
            runCatching {
                catalogRepository.upsertManualMovie(preferences.profileId, movie, telegramUrl, existing)
                catalogRepository.loadActive(preferences, refreshRemote = false)
            }.onSuccess {
                manualItems = catalogRepository.manualItems(preferences.profileId)
                onCatalogChanged(it)
                step = AdminStep.CATALOG_SUCCESS
            }.onFailure { message = it.message ?: "No se pudo agregar la película al catálogo." }
            busy = false
        }
    }

    fun search() {
        if (busy) return
        scope.launch {
            busy = true; message = null
            runCatching { metadataRepository.searchMovies(query, preferences) }
                .onSuccess { results = it; if (it.isEmpty()) message = "No se encontraron películas con ese nombre." }
                .onFailure { message = it.message ?: "No se pudo consultar TMDB." }
            busy = false
        }
    }

    fun searchEntry() {
        if (busy) return
        scope.launch {
            busy = true; message = null
            runCatching { metadataRepository.searchCatalogEntries(query, adminType, preferences) }
                .onSuccess { entryResults = it; if (it.isEmpty()) message = "No se encontraron resultados con ese nombre." }
                .onFailure { message = it.message ?: "No se pudo consultar el servicio de metadatos." }
            busy = false
        }
    }

    fun selectEntry(result: AdminSearchResult) {
        if (busy) return
        scope.launch {
            busy = true; message = "Obteniendo información…"
            runCatching { metadataRepository.loadCatalogEntryDraft(result, preferences) }
                .onSuccess { entryDraft = it; telegramUrl = ""; step = AdminStep.ENTRY_PREVIEW; message = null }
                .onFailure { message = it.message ?: "No se pudo obtener la ficha seleccionada." }
            busy = false
        }
    }

    fun saveEntryToCatalog(entry: CatalogEntryDraft, existing: VideoItem?) {
        if (busy) return
        scope.launch {
            busy = true; message = null
            runCatching {
                catalogRepository.upsertManualEntry(preferences.profileId, entry, telegramUrl, existing)
                catalogRepository.loadActive(preferences, refreshRemote = false)
            }.onSuccess {
                manualItems = catalogRepository.manualItems(preferences.profileId)
                onCatalogChanged(it)
                step = AdminStep.CATALOG_SUCCESS
            }.onFailure { message = it.message ?: "No se pudo agregar el contenido al catálogo." }
            busy = false
        }
    }

    fun select(movie: TmdbMovieSearchResult) {
        if (busy) return
        scope.launch {
            busy = true; message = "Obteniendo información y créditos…"
            runCatching { metadataRepository.loadMoviePublicationDraft(movie.id, preferences) }
                .onSuccess { draft = it; caption = it.caption; step = AdminStep.PREVIEW; message = null }
                .onFailure { message = it.message ?: "No se pudo obtener la información de la película." }
            busy = false
        }
    }

    BackHandler(enabled = step != AdminStep.HOME && !busy) {
        step = when (step) {
            AdminStep.SEARCH -> AdminStep.HOME
            AdminStep.PREVIEW -> AdminStep.SEARCH
            AdminStep.ENTRY_PREVIEW -> AdminStep.SEARCH
            AdminStep.SUCCESS -> AdminStep.HOME
            AdminStep.CATALOG_SUCCESS -> AdminStep.HOME
            AdminStep.MANUAL_ITEMS -> AdminStep.HOME
            AdminStep.HOME -> AdminStep.HOME
        }
    }

    when (step) {
        AdminStep.HOME -> AdminHome(
            manualCount = manualItems.size,
            busy = busy,
            message = message,
            canPublishOnline = preferences.catalogPublishUrl.isNotBlank() && snapshot != null,
            onMovie = {
                adminType = AdminContentType.MOVIE; query = ""; results = emptyList(); message = null; step = AdminStep.SEARCH
            },
            onSeries = {
                adminType = AdminContentType.SERIES; query = ""; entryResults = emptyList(); message = null; step = AdminStep.SEARCH
            },
            onAnime = {
                adminType = AdminContentType.ANIME; query = ""; entryResults = emptyList(); message = null; step = AdminStep.SEARCH
            },
            onManualItems = { message = null; step = AdminStep.MANUAL_ITEMS },
            onExport = { exportLauncher.launch("catalogo.json") },
            onShare = {
                if (snapshot != null) scope.launch {
                    busy = true
                    runCatching { catalogRepository.createShareCatalog(snapshot) }
                        .onSuccess { CatalogShareLauncher.share(context, it) }
                        .onFailure { message = it.message ?: "No se pudo compartir el catálogo." }
                    busy = false
                }
            },
            onPublishOnline = { confirmCatalogPublish = true }
        )
        AdminStep.SEARCH -> if (adminType == AdminContentType.MOVIE) {
            MovieSearch(
                query = query, onQuery = { query = it }, results = results, busy = busy, message = message,
                onSearch = ::search, onSelect = ::select, onBack = { step = AdminStep.HOME }
            )
        } else {
            CatalogEntrySearch(
                type = adminType, query = query, onQuery = { query = it }, results = entryResults,
                busy = busy, message = message, onSearch = ::searchEntry, onSelect = ::selectEntry,
                onBack = { step = AdminStep.HOME }
            )
        }
        AdminStep.PREVIEW -> draft?.let { movie ->
            PublicationPreview(
                draft = movie,
                caption = caption,
                onCaption = { caption = it },
                destination = preferences.telegramMovieChannelTitle ?: preferences.telegramMovieChatId.ifBlank { "Sin configurar" },
                busy = busy,
                stage = publishStage,
                message = message,
                telegramUrl = telegramUrl,
                onTelegramUrl = { telegramUrl = it },
                onBack = { step = AdminStep.SEARCH },
                onAddToCatalog = {
                    val found = catalogRepository.findMovieDuplicate(snapshot, movie.tmdbId)
                    if (found == null) saveMovieToCatalog(movie, null) else duplicate = found
                },
                onPublish = { confirmPublish = true }
            )
            if (confirmPublish) AlertDialog(
                onDismissRequest = { confirmPublish = false },
                icon = { Icon(Icons.Default.Send, null) },
                title = { Text("Confirmar publicación") },
                text = { Text("Se creará una publicación nueva en ${preferences.telegramMovieChannelTitle ?: preferences.telegramMovieChatId}. No se editará ni borrará contenido existente.") },
                confirmButton = {
                    Button(onClick = {
                        confirmPublish = false
                        scope.launch {
                            busy = true; message = null
                            runCatching {
                                telegramRepository.publishMovie(
                                    token = secretStore.getTelegramBotToken(),
                                    chatId = preferences.telegramMovieChatId,
                                    profileId = preferences.profileId,
                                    draft = movie,
                                    caption = caption,
                                    onStage = { publishStage = it }
                                )
                            }.onSuccess { result ->
                                store.savePublicationReceipt(preferences.profileId, telegramRepository.receipt(movie, caption, result))
                                completed = result; step = AdminStep.SUCCESS
                            }.onFailure { message = it.message ?: "No se pudo publicar." }
                            publishStage = null; busy = false
                        }
                    }) { Text("Sí, publicar") }
                },
                dismissButton = { TextButton(onClick = { confirmPublish = false }) { Text("Cancelar") } }
            )
        }
        AdminStep.ENTRY_PREVIEW -> entryDraft?.let { entry ->
            CatalogEntryPreview(
                draft = entry,
                telegramUrl = telegramUrl,
                onTelegramUrl = { telegramUrl = it },
                busy = busy,
                message = message,
                onBack = { step = AdminStep.SEARCH },
                onAdd = {
                    val found = catalogRepository.findDuplicate(snapshot, entry)
                    if (found == null) saveEntryToCatalog(entry, null) else entryDuplicate = found
                }
            )
        }
        AdminStep.SUCCESS -> PublicationSuccess(completed, onNew = {
            query = ""; results = emptyList(); draft = null; caption = ""; telegramUrl = ""; completed = null; message = null; step = AdminStep.HOME
        })
        AdminStep.CATALOG_SUCCESS -> CatalogSuccess(onBack = {
            query = ""; results = emptyList(); draft = null; caption = ""; telegramUrl = ""; message = null; step = AdminStep.HOME
        })
        AdminStep.MANUAL_ITEMS -> ManualItemsScreen(
            items = manualItems,
            busy = busy,
            message = message,
            onBack = { step = AdminStep.HOME },
            onUpdate = { item, url ->
                scope.launch {
                    busy = true
                    runCatching {
                        catalogRepository.updateManualTelegram(preferences.profileId, item.id, url)
                        catalogRepository.loadActive(preferences, false)
                    }.onSuccess {
                        manualItems = catalogRepository.manualItems(preferences.profileId)
                        onCatalogChanged(it); message = "Enlace actualizado."
                    }.onFailure { message = it.message ?: "No se pudo actualizar." }
                    busy = false
                }
            },
            onDelete = { item ->
                scope.launch {
                    busy = true
                    runCatching {
                        catalogRepository.deleteManualItem(preferences.profileId, item.id)
                        catalogRepository.loadActive(preferences, false)
                    }.onSuccess {
                        manualItems = catalogRepository.manualItems(preferences.profileId)
                        onCatalogChanged(it); message = "Entrada manual eliminada."
                    }.onFailure { message = it.message ?: "No se pudo eliminar." }
                    busy = false
                }
            }
        )
    }

    duplicate?.let { existing ->
        AlertDialog(
            onDismissRequest = { duplicate = null },
            title = { Text("La película ya existe") },
            text = { Text("${existing.titulo} ya está en el catálogo. Podés reemplazar sus datos y actualizar el enlace de Telegram.") },
            confirmButton = { Button(onClick = { duplicate = null; draft?.let { saveMovieToCatalog(it, existing) } }) { Text("Actualizar entrada") } },
            dismissButton = { TextButton(onClick = { duplicate = null }) { Text("Cancelar") } }
        )
    }

    entryDuplicate?.let { existing ->
        AlertDialog(
            onDismissRequest = { entryDuplicate = null },
            title = { Text("El contenido ya existe") },
            text = { Text("${existing.titulo} ya está en el catálogo. Podés reemplazar la ficha y actualizar su enlace de Telegram.") },
            confirmButton = { Button(onClick = { entryDuplicate = null; entryDraft?.let { saveEntryToCatalog(it, existing) } }) { Text("Actualizar entrada") } },
            dismissButton = { TextButton(onClick = { entryDuplicate = null }) { Text("Cancelar") } }
        )
    }

    if (confirmCatalogPublish) AlertDialog(
        onDismissRequest = { confirmCatalogPublish = false },
        title = { Text("Publicar catálogo online") },
        text = { Text("Se enviará el catálogo completo al servidor configurado y luego se comprobará la URL pública. Esto no publica películas ni modifica mensajes de Telegram.") },
        confirmButton = { Button(onClick = {
            confirmCatalogPublish = false
            val current = snapshot ?: return@Button
            scope.launch {
                busy = true; message = "Publicando y verificando catálogo…"
                runCatching { catalogRepository.publishCatalogOnline(preferences, current, secretStore.getCatalogAdminToken()) }
                    .onSuccess { onCatalogChanged(it); message = "Catálogo online actualizado y verificado." }
                    .onFailure { message = it.message ?: "No se pudo publicar el catálogo online." }
                busy = false
            }
        }) { Text("Publicar") } },
        dismissButton = { TextButton(onClick = { confirmCatalogPublish = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun AdminHome(
    manualCount: Int,
    busy: Boolean,
    message: String?,
    canPublishOnline: Boolean,
    onMovie: () -> Unit,
    onSeries: () -> Unit,
    onAnime: () -> Unit,
    onManualItems: () -> Unit,
    onExport: () -> Unit,
    onShare: () -> Unit,
    onPublishOnline: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Administrar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
        Text("Nueva incorporación", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Buscá la ficha, pegá el enlace del contenido en Telegram y agregalo al catálogo. Para películas también podés publicar la carátula + descripción en tu canal.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        AdminTypeCard("Película", "Agregar al catálogo o preparar una publicación", Icons.Default.Movie, true, onMovie)
        AdminTypeCard("Serie", "Buscar en TMDB y agregar al catálogo", Icons.Default.Tv, true, onSeries)
        AdminTypeCard("Anime", "Buscar en AniList y agregar al catálogo", Icons.Default.Animation, true, onAnime)
        HorizontalDivider()
        Text("Catálogo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        CatalogExplanation()
        OutlinedButton(onClick = onManualItems, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
            Icon(Icons.Default.EditNote, null); Spacer(Modifier.width(8.dp)); Text("Contenido agregado manualmente ($manualCount)")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onExport, modifier = Modifier.weight(1f), enabled = !busy) {
                Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(6.dp)); Text("Guardar JSON")
            }
            OutlinedButton(onClick = onShare, modifier = Modifier.weight(1f), enabled = !busy) {
                Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text("Compartir")
            }
        }
        Button(onClick = onPublishOnline, modifier = Modifier.fillMaxWidth(), enabled = !busy && canPublishOnline) {
            Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("Publicar catálogo online")
        }
        if (!canPublishOnline) Text("Para publicar online configurá la URL y la clave en Configuración > Catálogo > Publicación online avanzada.", style = MaterialTheme.typography.bodySmall)
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
    }
}

@Composable
private fun CatalogExplanation() {
    var expanded by remember { mutableStateOf(false) }
    OutlinedCard(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.HelpOutline, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("¿Cómo funciona el catálogo?", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
            }
            if (expanded) {
                Text(
                    "La app combina la fuente activa (remota o archivo local) con lo que agregás manualmente en este teléfono. " +
                        "Guardar JSON crea una copia completa. Compartir la envía como archivo. Publicar online reemplaza el catálogo del servidor sólo después de validarlo; " +
                        "los otros teléfonos lo reciben al abrir o al tocar Actualizar. Agregar aquí no modifica Telegram ni el catálogo online hasta que elijas publicar.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }
    }
}

@Composable
private fun AdminTypeCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Card(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(subtitle) }
            Icon(if (enabled) Icons.Default.ChevronRight else Icons.Default.LockClock, null)
        }
    }
}

@Composable
private fun CatalogEntrySearch(
    type: AdminContentType,
    query: String,
    onQuery: (String) -> Unit,
    results: List<AdminSearchResult>,
    busy: Boolean,
    message: String?,
    onSearch: () -> Unit,
    onSelect: (AdminSearchResult) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderWithBack("Nueva ${type.displayName.lowercase()}", onBack)
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            enabled = !busy,
            singleLine = true,
            label = { Text("Nombre de ${if (type == AdminContentType.ANIME) "anime" else "la serie"}") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = { IconButton(onClick = onSearch, enabled = !busy) { Icon(Icons.Default.ArrowForward, "Buscar") } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSearch() }),
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        )
        Text(
            if (type == AdminContentType.ANIME) "Resultados de AniList. Seleccioná manualmente la ficha correcta."
            else "Resultados de TMDB. Seleccioná manualmente la ficha correcta.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, color = if (busy) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp)) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(results, key = { "${it.contentType}-${it.id}" }) { result ->
                Card(onClick = { onSelect(result) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(result.posterUrl, null, contentScale = ContentScale.Crop, modifier = Modifier.width(64.dp).aspectRatio(2f / 3f))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(result.title, fontWeight = FontWeight.Bold)
                            result.originalTitle?.takeIf { !it.equals(result.title, true) }?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                            Text(result.year ?: "Año no disponible", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
    }
}

@Composable
private fun CatalogEntryPreview(
    draft: CatalogEntryDraft,
    telegramUrl: String,
    onTelegramUrl: (String) -> Unit,
    busy: Boolean,
    message: String?,
    onBack: () -> Unit,
    onAdd: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        HeaderWithBack("Revisar ${draft.contentType.displayName.lowercase()}", onBack)
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AsyncImage(draft.posterUrl, draft.title, contentScale = ContentScale.Crop,
                modifier = Modifier.width(120.dp).aspectRatio(2f / 3f))
            Column(Modifier.weight(1f)) {
                Text(draft.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                draft.originalTitle?.takeIf { !it.equals(draft.title, true) }?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                Text(listOfNotNull(draft.year?.toString(), draft.genres.take(3).takeIf { it.isNotEmpty() }?.joinToString(" • ")).joinToString(" • "),
                    color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
                Text(if (draft.trailerUrl != null) "Tráiler disponible" else "Sin tráiler disponible", style = MaterialTheme.typography.labelMedium)
            }
        }
        draft.synopsis?.let { Text(it, modifier = Modifier.padding(top = 14.dp)) }
        if (draft.synopsis.isNullOrBlank()) Text("No se encontró una sinopsis; la ficha podrá seguir agregándose.", color = MaterialTheme.colorScheme.tertiary, modifier = Modifier.padding(top = 12.dp))
        OutlinedTextField(
            value = telegramUrl,
            onValueChange = onTelegramUrl,
            enabled = !busy,
            label = { Text("Enlace del contenido en Telegram") },
            placeholder = { Text("https://t.me/c/1692370597/1847") },
            supportingText = { Text("Puede ser el mensaje principal de la serie o anime. Los episodios individuales podrán incorporarse después.") },
            keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Uri),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp)
        )
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 12.dp))
        message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp)) }
        Button(onClick = onAdd, enabled = !busy && telegramUrl.isNotBlank(), modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
            Icon(Icons.Default.PlaylistAdd, null); Spacer(Modifier.width(8.dp)); Text("Agregar a Mi Videoteca")
        }
    }
}

@Composable
private fun MovieSearch(
    query: String,
    onQuery: (String) -> Unit,
    results: List<TmdbMovieSearchResult>,
    busy: Boolean,
    message: String?,
    onSearch: () -> Unit,
    onSelect: (TmdbMovieSearchResult) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderWithBack("Nueva película", onBack)
        OutlinedTextField(
            value = query, onValueChange = onQuery, enabled = !busy, singleLine = true,
            label = { Text("Nombre de la película") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = { IconButton(onClick = onSearch, enabled = !busy) { Icon(Icons.Default.ArrowForward, "Buscar") } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { onSearch() }),
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        )
        Text("Seleccioná manualmente el resultado correcto; nunca se publicará automáticamente.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, color = if (busy) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp)) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(results, key = { it.id }) { movie ->
                Card(onClick = { onSelect(movie) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(movie.posterUrl, null, contentScale = ContentScale.Crop, modifier = Modifier.width(64.dp).aspectRatio(2f / 3f))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(movie.title, fontWeight = FontWeight.Bold)
                            movie.originalTitle?.takeIf { !it.equals(movie.title, true) }?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                            Text(movie.year ?: "Año no disponible", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
    }
}

@Composable
private fun PublicationPreview(
    draft: MoviePublicationDraft,
    caption: String,
    onCaption: (String) -> Unit,
    destination: String,
    busy: Boolean,
    stage: PublishStage?,
    message: String?,
    telegramUrl: String,
    onTelegramUrl: (String) -> Unit,
    onBack: () -> Unit,
    onAddToCatalog: () -> Unit,
    onPublish: () -> Unit
) {
    val tooLong = caption.length > PublicationFormatter.TELEGRAM_PHOTO_CAPTION_LIMIT
    val missing = buildList {
        if (draft.latinTitle.isNullOrBlank()) add("No se encontró un título confiable para Hispanoamérica; podés escribirlo u omitirlo.")
        if (draft.synopsis.isNullOrBlank()) add("TMDB no proporcionó una sinopsis en español.")
        if (draft.directors.isEmpty()) add("No se encontró información de dirección.")
        if (draft.countries.isEmpty()) add("No se encontró el país de producción.")
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        HeaderWithBack("Vista previa", onBack)
        Text("Destino: $destination", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        Text("Modo: Solo carátula + descripción", color = MaterialTheme.colorScheme.onSurfaceVariant)
        BoxWithConstraints(Modifier.fillMaxWidth().padding(top = 12.dp)) {
            if (maxWidth >= 600.dp) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    CaptionEditor(caption, onCaption, tooLong, Modifier.weight(1.4f))
                    PosterPreview(draft.posterUrl, Modifier.weight(.6f))
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    PosterPreview(draft.posterUrl, Modifier.fillMaxWidth().heightIn(max = 330.dp))
                    CaptionEditor(caption, onCaption, tooLong, Modifier.fillMaxWidth())
                }
            }
        }
        missing.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary, modifier = Modifier.padding(top = 5.dp)) }
        OutlinedTextField(
            value = telegramUrl,
            onValueChange = onTelegramUrl,
            enabled = !busy,
            label = { Text("Enlace del video en Telegram") },
            placeholder = { Text("https://t.me/c/1692370597/1847") },
            supportingText = { Text("Pegá el enlace completo del mensaje donde está alojada la película.") },
            keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Uri),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        )
        message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp)) }
        stage?.let { Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)); Text(it.label) } }
        Button(
            onClick = onAddToCatalog,
            enabled = !busy && telegramUrl.isNotBlank() && draft.title.isNotBlank(),
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) { Icon(Icons.Default.PlaylistAdd, null); Spacer(Modifier.width(8.dp)); Text("Agregar a Mi Videoteca") }
        Button(
            onClick = onPublish,
            enabled = !busy && !tooLong && caption.isNotBlank() && !draft.posterUrl.isNullOrBlank() && destination != "Sin configurar",
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        ) { Icon(Icons.Default.Send, null); Spacer(Modifier.width(8.dp)); Text("Publicar carátula + descripción") }
        if (destination == "Sin configurar") Text("Configurá el canal de películas en Configuración > Telegram.", color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun CaptionEditor(caption: String, onCaption: (String) -> Unit, tooLong: Boolean, modifier: Modifier) {
    OutlinedTextField(
        value = caption, onValueChange = onCaption, modifier = modifier.heightIn(min = 360.dp),
        label = { Text("Texto / descripción") }, isError = tooLong,
        supportingText = { Text("${caption.length}/${PublicationFormatter.TELEGRAM_PHOTO_CAPTION_LIMIT} caracteres" + if (tooLong) " — editá el texto antes de publicar" else "") }
    )
}

@Composable
private fun PosterPreview(url: String?, modifier: Modifier) {
    Card(modifier.aspectRatio(2f / 3f)) {
        if (url == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Carátula no disponible") }
        else AsyncImage(url, "Carátula", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
    }
}

@Composable
private fun PublicationSuccess(result: TelegramPublishResult?, onNew: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(72.dp))
        Text("Publicación completada", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        Text("Telegram confirmó la publicación${result?.channelTitle?.let { " en $it" }.orEmpty()}.", modifier = Modifier.padding(top = 8.dp))
        result?.let { Text("message_id: ${it.messageId}", style = MaterialTheme.typography.bodySmall) }
        Button(onClick = onNew, modifier = Modifier.padding(top = 24.dp)) { Text("Volver a Administrar") }
    }
}

@Composable
private fun CatalogSuccess(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.LibraryAddCheck, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(72.dp))
        Text("Contenido agregado", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        Text("Ya forma parte de Mi Videoteca. Podés exportar, compartir o publicar online el catalogo.json actualizado.", modifier = Modifier.padding(top = 8.dp))
        Button(onClick = onBack, modifier = Modifier.padding(top = 24.dp)) { Text("Volver a Administrar") }
    }
}

@Composable
private fun ManualItemsScreen(
    items: List<VideoItem>,
    busy: Boolean,
    message: String?,
    onBack: () -> Unit,
    onUpdate: (VideoItem, String) -> Unit,
    onDelete: (VideoItem) -> Unit
) {
    var editing by remember { mutableStateOf<VideoItem?>(null) }
    var editUrl by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf<VideoItem?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderWithBack("Contenido manual", onBack)
        Text("Estas entradas se fusionan con el catálogo activo y no se pierden al actualizar la fuente remota.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 6.dp)) }
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Todavía no agregaste contenido manualmente.") }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { item ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(item.posterUrl, null, contentScale = ContentScale.Crop, modifier = Modifier.width(52.dp).aspectRatio(2f / 3f))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.titulo, fontWeight = FontWeight.Bold)
                                Text(item.telegramUrl.orEmpty(), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                            }
                            IconButton(onClick = { editing = item; editUrl = item.telegramUrl.orEmpty() }, enabled = !busy) { Icon(Icons.Default.Edit, "Editar enlace") }
                            IconButton(onClick = { deleting = item }, enabled = !busy) { Icon(Icons.Default.Delete, "Eliminar") }
                        }
                    }
                }
            }
        }
    }
    editing?.let { item ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Editar enlace de Telegram") },
            text = { OutlinedTextField(value = editUrl, onValueChange = { editUrl = it }, label = { Text("Enlace completo") }, singleLine = true) },
            confirmButton = { Button(onClick = { editing = null; onUpdate(item, editUrl) }) { Text("Guardar") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancelar") } }
        )
    }
    deleting?.let { item ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Eliminar entrada manual") },
            text = { Text("Se quitará ${item.titulo} de las incorporaciones manuales. No se borrará ningún mensaje ni video de Telegram.") },
            confirmButton = { Button(onClick = { deleting = null; onDelete(item) }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } }
        )
    }
}
