package com.mivideoteca.app.data

import com.google.gson.JsonObject
import com.google.gson.JsonParser

class CatalogValidator {
    companion object {
        private val SUPPORTED_SCHEMA_MAJORS = setOf("1")
        private val VALID_TYPES = setOf("pelicula", "serie", "anime")
    }

    fun validate(json: String, sourceLabel: String): CatalogSnapshot {
        val root = try {
            JsonParser.parseString(json).asJsonObject
        } catch (e: Exception) {
            throw IllegalArgumentException("El archivo no contiene JSON válido.")
        }
        val schema = root.stringOrNull("schema_version")
            ?: throw IllegalArgumentException("Falta schema_version.")
        if (schema.substringBefore('.') !in SUPPORTED_SCHEMA_MAJORS) {
            throw IllegalArgumentException("schema_version $schema no es compatible. Se admite la versión 1.x.")
        }
        val array = root.getAsJsonArray("items")
            ?: throw IllegalArgumentException("Falta la lista items.")

        val valid = mutableListOf<VideoItem>()
        val issues = mutableListOf<ValidationIssue>()
        val seenIds = mutableSetOf<String>()

        array.forEachIndexed { index, element ->
            val obj = element.takeIf { it.isJsonObject }?.asJsonObject
            if (obj == null) {
                issues += ValidationIssue(index, null, "La entrada no es un objeto JSON.")
                return@forEachIndexed
            }
            val id = obj.stringOrNull("id")
            val type = obj.stringOrNull("tipo")?.lowercase()
            val title = obj.stringOrNull("titulo")
            val telegram = obj.stringOrNull("telegram_url")

            val error = when {
                id.isNullOrBlank() -> "Falta id."
                !seenIds.add(id) -> "El id '$id' está repetido."
                type !in VALID_TYPES -> "Tipo '$type' no válido."
                title.isNullOrBlank() -> "Falta titulo."
                type == "anime" && obj.longOrNull("anilist_id") == null && obj.stringOrNull("poster_url").isNullOrBlank() ->
                    "Anime sin anilist_id ni poster_url."
                type != "anime" && obj.longOrNull("tmdb_id") == null && obj.stringOrNull("poster_url").isNullOrBlank() ->
                    "Contenido sin tmdb_id ni poster_url."
                !telegram.isNullOrBlank() && !isSafeUrl(telegram) -> "telegram_url no es una URL HTTPS de Telegram."
                else -> null
            }
            if (error != null) {
                issues += ValidationIssue(index, id, error)
                return@forEachIndexed
            }
            try {
                val seasons = obj.getAsJsonArray("temporadas")?.mapNotNull { seasonElement ->
                    val season = seasonElement.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                    val number = season.intOrNull("numero") ?: return@mapNotNull null
                    val episodes = season.getAsJsonArray("episodios")?.mapNotNull episodeLoop@{ episodeElement ->
                        val episode = episodeElement.takeIf { it.isJsonObject }?.asJsonObject ?: return@episodeLoop null
                        val episodeId = episode.stringOrNull("id")
                        val episodeNumber = episode.intOrNull("numero")
                        val episodeUrl = episode.stringOrNull("telegram_url")
                        if (episodeId.isNullOrBlank() || episodeNumber == null || (!episodeUrl.isNullOrBlank() && !isSafeUrl(episodeUrl))) {
                            issues += ValidationIssue(index, id, "Un episodio de la temporada $number fue ignorado por datos inválidos.")
                            return@episodeLoop null
                        }
                        Episode(
                            id = episodeId,
                            numero = episodeNumber,
                            titulo = episode.stringOrNull("titulo"),
                            duracion = episode.stringOrNull("duracion"),
                            thumbnailUrl = episode.stringOrNull("thumbnail_url"),
                            telegramUrl = episodeUrl
                        )
                    }.orEmpty()
                    Season(number, season.stringOrNull("titulo"), episodes)
                }.orEmpty()
                valid += VideoItem(
                    id = id!!,
                    tipo = type!!,
                    titulo = title!!,
                    tituloOriginal = obj.stringOrNull("titulo_original"),
                    titulosAlternativos = obj.stringList("titulos_alternativos"),
                    year = obj.intOrNull("year"),
                    generos = obj.stringList("generos"),
                    calidad = obj.stringOrNull("calidad"),
                    duracion = obj.stringOrNull("duracion"),
                    sinopsis = obj.stringOrNull("sinopsis"),
                    posterUrl = obj.stringOrNull("poster_url"),
                    backdropUrl = obj.stringOrNull("backdrop_url"),
                    trailerUrl = obj.stringOrNull("trailer_url"),
                    tmdbId = obj.longOrNull("tmdb_id"),
                    anilistId = obj.longOrNull("anilist_id"),
                    telegramUrl = telegram,
                    fechaAgregado = obj.stringOrNull("fecha_agregado"),
                    audio = obj.stringOrNull("audio"),
                    subtitulos = obj.stringOrNull("subtitulos"),
                    temporadas = seasons
                )
            } catch (e: Exception) {
                issues += ValidationIssue(index, id, "No se pudo interpretar: ${e.message ?: "error desconocido"}")
            }
        }
        if (valid.isEmpty()) throw IllegalArgumentException("El catálogo no contiene ninguna entrada válida.")
        return CatalogSnapshot(
            schemaVersion = schema,
            updatedAt = root.stringOrNull("actualizado_en"),
            items = valid,
            issues = issues,
            loadedAtMillis = System.currentTimeMillis(),
            sourceLabel = sourceLabel
        )
    }

    private fun isSafeUrl(value: String): Boolean = runCatching {
        val uri = java.net.URI(value)
        uri.scheme == "https" && (uri.host == "t.me" || uri.host == "telegram.me")
    }.getOrDefault(false)

    private fun JsonObject.stringOrNull(name: String): String? =
        get(name)?.takeUnless { it.isJsonNull }?.asString

    private fun JsonObject.longOrNull(name: String): Long? =
        runCatching { get(name)?.takeUnless { it.isJsonNull }?.asLong }.getOrNull()

    private fun JsonObject.intOrNull(name: String): Int? =
        runCatching { get(name)?.takeUnless { it.isJsonNull }?.asInt }.getOrNull()

    private fun JsonObject.stringList(name: String): List<String> =
        runCatching { getAsJsonArray(name)?.mapNotNull { it.takeUnless { value -> value.isJsonNull }?.asString } }.getOrNull().orEmpty()
}
