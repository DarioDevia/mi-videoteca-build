package com.mivideoteca.app.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.mivideoteca.app.BuildConfig
import java.io.File

object CatalogShareLauncher {
    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.files", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Catálogo de Mi Videoteca")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Compartir catalogo.json"))
    }
}
