package com.mivideoteca.app.data

data class TmdbMovieSearchResult(
    val id: Long,
    val title: String,
    val originalTitle: String?,
    val releaseDate: String?,
    val posterUrl: String?
) {
    val year: String? get() = releaseDate?.take(4)?.takeIf { it.all(Char::isDigit) }
}

enum class AdminContentType(val catalogValue: String, val displayName: String) {
    MOVIE("pelicula", "Película"),
    SERIES("serie", "Serie"),
    ANIME("anime", "Anime")
}

data class AdminSearchResult(
    val id: Long,
    val contentType: AdminContentType,
    val title: String,
    val originalTitle: String?,
    val releaseDate: String?,
    val posterUrl: String?
) {
    val year: String? get() = releaseDate?.take(4)?.takeIf { it.all(Char::isDigit) }
}

data class CatalogEntryDraft(
    val sourceId: Long,
    val contentType: AdminContentType,
    val title: String,
    val originalTitle: String?,
    val alternativeTitles: List<String> = emptyList(),
    val year: Int?,
    val synopsis: String?,
    val genres: List<String> = emptyList(),
    val duration: String? = null,
    val posterUrl: String?,
    val backdropUrl: String?,
    val trailerUrl: String? = null
)

data class ProductionCountry(val code: String, val name: String, val flag: String)

data class MoviePublicationDraft(
    val tmdbId: Long,
    val title: String,
    val originalTitle: String?,
    val latinTitle: String?,
    val alternativeTitles: List<String>,
    val year: String?,
    val releaseDate: String?,
    val posterUrl: String?,
    val backdropUrl: String?,
    val synopsis: String?,
    val genres: List<String>,
    val runtimeMinutes: Int?,
    val cast: List<String>,
    val directors: List<String>,
    val countries: List<ProductionCountry>,
    val caption: String,
    val trailerUrl: String? = null
)

enum class PublicationMode { COVER_AND_DESCRIPTION, VIDEO_ONLY, COMPLETE }

data class TelegramConnectionReport(
    val connected: Boolean,
    val channelFound: Boolean,
    val canPublish: Boolean,
    val channelTitle: String?,
    val detail: String
)

data class TelegramPublishResult(
    val messageId: Long,
    val channelTitle: String?,
    val chatId: String
)

data class PublicationReceipt(
    val tmdbId: Long,
    val chatId: String,
    val channelTitle: String?,
    val messageId: Long,
    val publishedAtMillis: Long,
    val posterUrl: String,
    val captionSha256: String
)

enum class PublishStage(val label: String) {
    PREPARING("Preparando carátula…"),
    CONNECTING("Conectando con Telegram…"),
    PUBLISHING("Publicando…"),
    VERIFYING("Verificando…")
}

object PublicationFormatter {
    const val TELEGRAM_PHOTO_CAPTION_LIMIT = 1024

    fun movieCaption(
        title: String,
        year: String?,
        latinTitle: String?,
        synopsis: String?,
        cast: List<String>,
        directors: List<String>,
        countries: List<ProductionCountry>
    ): String = buildList {
        add(title.trim() + year?.takeIf { it.isNotBlank() }?.let { " ($it)" }.orEmpty())
        latinTitle?.trim()?.takeIf { it.isNotBlank() && !it.equals(title.trim(), true) }?.let { add("-$it") }
        synopsis?.trim()?.takeIf { it.isNotBlank() }?.let { add(""); add("SINOPSIS: $it") }
        if (cast.isNotEmpty()) { add(""); add("REPARTO:"); add(cast.joinToString(", ") + ".") }
        if (directors.isNotEmpty()) { add(""); add("Dirigida por: ${naturalJoin(directors)}") }
        if (countries.isNotEmpty()) add(countries.take(3).joinToString(" • ") { "${it.name} ${it.flag}" })
    }.joinToString("\n")

    fun naturalJoin(values: List<String>): String = when (values.size) {
        0 -> ""
        1 -> values.first()
        else -> values.dropLast(1).joinToString(", ") + " y " + values.last()
    }

    fun countryFlag(code: String): String {
        val normalized = code.uppercase()
        if (normalized.length != 2 || normalized.any { it !in 'A'..'Z' }) return ""
        return normalized.map { char -> Character.toChars(0x1F1E6 + (char - 'A')).concatToString() }.joinToString("")
    }
}
