package com.mivideoteca.app.data

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.time.Instant
import java.time.LocalDate

class CatalogRepository(
    private val context: Context,
    private val store: AppStore,
    private val validator: CatalogValidator = CatalogValidator()
) {
    companion object {
        const val DEFAULT_URL = "https://small-breeze-e454.deviadario.workers.dev/"
    }

    private val client = NetworkClient.http
    private val gson = Gson()
    private val prettyGson = GsonBuilder().setPrettyPrinting().create()

    suspend fun loadActive(preferences: AppPreferences, refreshRemote: Boolean = true): CatalogSnapshot =
        withContext(Dispatchers.IO) {
            val base = when (preferences.source) {
                CatalogSource.REMOTE -> if (refreshRemote) {
                    runCatching { downloadRemote(preferences, save = true) }
                        .getOrElse { error ->
                            logError(preferences.profileId, "Catálogo remoto: ${safeMessage(error)}")
                            loadCache(preferences.profileId, remoteFile(preferences.profileId), "Copia remota almacenada", true)
                                ?: loadFallback("Catálogo de demostración", true)
                        }
                } else {
                    loadCache(preferences.profileId, remoteFile(preferences.profileId), "Copia remota almacenada", true)
                        ?: loadFallback("Catálogo de demostración", true)
                }
                CatalogSource.LOCAL ->
                    loadCache(preferences.profileId, localFile(preferences.profileId), preferences.localFileName ?: "Archivo local", false)
                        ?: throw IllegalStateException("Todavía no seleccionaste un catálogo local.")
            }
            mergeManual(preferences.profileId, base)
        }

    fun manualItems(profileId: String): List<VideoItem> = readManualCatalog(profileId)?.items.orEmpty()

    fun findMovieDuplicate(snapshot: CatalogSnapshot?, tmdbId: Long): VideoItem? =
        snapshot?.items?.firstOrNull { it.tipo == "pelicula" && it.tmdbId == tmdbId }

    fun findDuplicate(snapshot: CatalogSnapshot?, draft: CatalogEntryDraft): VideoItem? = snapshot?.items?.firstOrNull {
        it.tipo == draft.contentType.catalogValue && when (draft.contentType) {
            AdminContentType.ANIME -> it.anilistId == draft.sourceId
            else -> it.tmdbId == draft.sourceId
        }
    }

    suspend fun upsertManualEntry(
        profileId: String,
        draft: CatalogEntryDraft,
        telegramUrl: String,
        existing: VideoItem? = null
    ) = withContext(Dispatchers.IO) {
        requireTelegramUrl(telegramUrl)
        val current = manualItems(profileId).toMutableList()
        val prefix = draft.contentType.catalogValue
        val source = if (draft.contentType == AdminContentType.ANIME) "anilist" else "tmdb"
        val itemId = existing?.id ?: "$prefix-$source-${draft.sourceId}"
        val item = VideoItem(
            id = itemId,
            tipo = draft.contentType.catalogValue,
            titulo = draft.title.trim(),
            tituloOriginal = draft.originalTitle?.trim()?.takeIf(String::isNotBlank),
            titulosAlternativos = draft.alternativeTitles.map(String::trim).filter(String::isNotBlank).distinct(),
            year = draft.year,
            generos = draft.genres,
            duracion = draft.duration,
            sinopsis = draft.synopsis?.trim()?.takeIf(String::isNotBlank),
            posterUrl = draft.posterUrl,
            backdropUrl = draft.backdropUrl,
            trailerUrl = draft.trailerUrl,
            tmdbId = draft.sourceId.takeUnless { draft.contentType == AdminContentType.ANIME },
            anilistId = draft.sourceId.takeIf { draft.contentType == AdminContentType.ANIME },
            telegramUrl = telegramUrl.trim(),
            fechaAgregado = existing?.fechaAgregado ?: LocalDate.now().toString()
        )
        current.removeAll { candidate ->
            candidate.id == itemId || (candidate.tipo == item.tipo && when (draft.contentType) {
                AdminContentType.ANIME -> candidate.anilistId == draft.sourceId
                else -> candidate.tmdbId == draft.sourceId
            })
        }
        current += item
        saveManualCatalog(profileId, current)
    }

    suspend fun upsertManualMovie(
        profileId: String,
        draft: MoviePublicationDraft,
        telegramUrl: String,
        existing: VideoItem? = null
    ) = withContext(Dispatchers.IO) {
        requireTelegramUrl(telegramUrl)
        val current = manualItems(profileId).toMutableList()
        val itemId = existing?.id ?: "pelicula-tmdb-${draft.tmdbId}"
        val item = VideoItem(
            id = itemId,
            tipo = "pelicula",
            titulo = draft.title.trim(),
            tituloOriginal = draft.originalTitle?.trim()?.takeIf(String::isNotBlank),
            titulosAlternativos = (draft.alternativeTitles + listOfNotNull(draft.latinTitle))
                .map(String::trim).filter(String::isNotBlank).distinct(),
            year = draft.year?.toIntOrNull(),
            generos = draft.genres,
            duracion = draft.runtimeMinutes?.let { "$it min" },
            sinopsis = draft.synopsis?.trim()?.takeIf(String::isNotBlank),
            posterUrl = draft.posterUrl,
            backdropUrl = draft.backdropUrl,
            trailerUrl = draft.trailerUrl,
            tmdbId = draft.tmdbId,
            telegramUrl = telegramUrl.trim(),
            fechaAgregado = existing?.fechaAgregado ?: LocalDate.now().toString()
        )
        current.removeAll { it.id == itemId || it.tmdbId == draft.tmdbId }
        current += item
        saveManualCatalog(profileId, current)
    }

    suspend fun updateManualTelegram(profileId: String, itemId: String, telegramUrl: String) = withContext(Dispatchers.IO) {
        requireTelegramUrl(telegramUrl)
        val current = manualItems(profileId).toMutableList()
        val index = current.indexOfFirst { it.id == itemId }
        require(index >= 0) { "La película manual ya no existe." }
        current[index] = current[index].copy(telegramUrl = telegramUrl.trim())
        saveManualCatalog(profileId, current)
    }

    suspend fun deleteManualItem(profileId: String, itemId: String) = withContext(Dispatchers.IO) {
        val current = manualItems(profileId).filterNot { it.id == itemId }
        saveManualCatalog(profileId, current)
    }

    fun catalogJson(snapshot: CatalogSnapshot): String = prettyGson.toJson(
        CatalogoResponse(
            schemaVersion = snapshot.schemaVersion,
            actualizadoEn = Instant.now().toString(),
            items = snapshot.items
        )
    )

    suspend fun exportCatalog(snapshot: CatalogSnapshot, uri: Uri) = withContext(Dispatchers.IO) {
        val json = catalogJson(snapshot)
        validator.validate(json, "Catálogo exportado")
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(json) }
            ?: throw IllegalStateException("No se pudo escribir el archivo seleccionado.")
    }

    suspend fun createShareCatalog(snapshot: CatalogSnapshot): File = withContext(Dispatchers.IO) {
        val json = catalogJson(snapshot)
        validator.validate(json, "Catálogo para compartir")
        File(context.cacheDir, "shared_catalog/catalogo.json").apply {
            parentFile?.mkdirs()
            writeText(json)
        }
    }

    suspend fun publishCatalogOnline(
        preferences: AppPreferences,
        snapshot: CatalogSnapshot,
        adminToken: String?
    ): CatalogSnapshot = withContext(Dispatchers.IO) {
        requireHttps(preferences.catalogPublishUrl)
        require(!adminToken.isNullOrBlank()) { "Falta configurar la clave administrativa del catálogo." }
        val json = catalogJson(snapshot)
        validator.validate(json, "Catálogo preparado para publicar")
        val request = Request.Builder()
            .url(preferences.catalogPublishUrl)
            .header("Authorization", "Bearer $adminToken")
            .header("Accept", "application/json")
            .put(json.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException(when (response.code) {
                    401, 403 -> "El servidor rechazó la clave administrativa."
                    404, 405 -> "La dirección configurada no admite publicar el catálogo mediante PUT."
                    409, 412 -> "El servidor rechazó la actualización porque existe una versión más reciente."
                    else -> "El servidor rechazó la publicación (HTTP ${response.code})."
                })
            }
        }
        val verified = testRemote(preferences.remoteUrl)
        val expectedIds = snapshot.items.mapTo(mutableSetOf()) { it.id }
        val verifiedIds = verified.items.mapTo(mutableSetOf()) { it.id }
        require(verifiedIds.containsAll(expectedIds)) {
            "El servidor aceptó la solicitud, pero el catálogo público todavía no contiene todas las entradas. No se confirmó la actualización."
        }
        verified
    }

    suspend fun testRemote(url: String): CatalogSnapshot = withContext(Dispatchers.IO) {
        requireHttps(url)
        val json = getText(url)
        validator.validate(json, "Prueba remota")
    }

    suspend fun downloadRemote(preferences: AppPreferences, save: Boolean): CatalogSnapshot = withContext(Dispatchers.IO) {
        requireHttps(preferences.remoteUrl)
        val json = getText(preferences.remoteUrl)
        val validated = validator.validate(json, "Catálogo remoto")
        if (save) atomicSave(remoteFile(preferences.profileId), json)
        validated
    }

    suspend fun importLocal(profileId: String, uri: Uri, displayName: String): CatalogSnapshot = withContext(Dispatchers.IO) {
        val json = context.contentResolver.openInputStream(uri)?.use { input ->
            input.bufferedReader().use { it.readText() }
        } ?: throw IllegalArgumentException("No se pudo abrir el archivo seleccionado.")
        val validated = validator.validate(json, displayName)
        atomicSave(localFile(profileId), json)
        validated
    }

    suspend fun reloadLocal(preferences: AppPreferences): CatalogSnapshot = withContext(Dispatchers.IO) {
        loadCache(preferences.profileId, localFile(preferences.profileId), preferences.localFileName ?: "Archivo local", false)
            ?: throw IllegalStateException("No hay una copia local válida.")
    }

    suspend fun testServices(preferences: AppPreferences): ServiceStatus = withContext(Dispatchers.IO) {
        val catalogStatus = runCatching {
            if (preferences.source == CatalogSource.REMOTE) testRemote(preferences.remoteUrl)
            else reloadLocal(preferences)
            "Correcto"
        }.getOrElse { "Error: ${safeMessage(it)}" }

        val tmdbStatus = if (preferences.tmdbToken.isBlank()) "Sin token" else runCatching {
            val request = Request.Builder()
                .url("https://api.themoviedb.org/3/authentication")
                .header("Authorization", "Bearer ${preferences.tmdbToken}")
                .build()
            client.newCall(request).execute().use { if (it.isSuccessful) "Correcto" else "Error HTTP ${it.code}" }
        }.getOrElse { "Error: ${safeMessage(it)}" }

        val query = """{"query":"query { Media(id: 154587) { id } }"}"""
        val anilistStatus = runCatching {
            val request = Request.Builder()
                .url("https://graphql.anilist.co")
                .post(query.toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(request).execute().use { if (it.isSuccessful) "Correcto" else "Error HTTP ${it.code}" }
        }.getOrElse { "Error: ${safeMessage(it)}" }

        ServiceStatus(catalogStatus, tmdbStatus, anilistStatus)
    }

    fun recentErrors(profileId: String): List<String> =
        errorFile(profileId).takeIf { it.exists() }?.readLines()?.takeLast(30)?.reversed() ?: emptyList()

    fun clearErrors(profileId: String) { errorFile(profileId).delete() }

    fun metadataCacheBytes(profileId: String): Long = directoryBytes(File(store.profileDir(profileId), "metadata"))

    fun clearMetadataCache(profileId: String) {
        File(store.profileDir(profileId), "metadata").deleteRecursively()
    }

    private fun getText(url: String): String {
        val request = Request.Builder().url(url).header("Accept", "application/json").build()
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("El servidor respondió HTTP ${response.code}.")
            response.body?.string() ?: throw IllegalStateException("El servidor devolvió una respuesta vacía.")
        }
    }

    private fun requireHttps(url: String) {
        val uri = runCatching { java.net.URI(url) }.getOrNull()
        require(uri?.scheme == "https" && !uri.host.isNullOrBlank()) { "La dirección debe ser una URL HTTPS válida." }
    }

    private fun requireTelegramUrl(value: String) {
        val uri = runCatching { java.net.URI(value.trim()) }.getOrNull()
        require(uri?.scheme == "https" && (uri.host == "t.me" || uri.host == "telegram.me") && !uri.path.isNullOrBlank()) {
            "Pegá el enlace HTTPS completo del mensaje de Telegram, por ejemplo https://t.me/c/123456/789."
        }
    }

    private fun mergeManual(profileId: String, base: CatalogSnapshot): CatalogSnapshot {
        val manual = readManualCatalog(profileId) ?: return base
        val merged = LinkedHashMap<String, VideoItem>()
        base.items.forEach { merged[it.id] = it }
        manual.items.forEach { item ->
            val duplicateKey = merged.entries.firstOrNull {
                item.tmdbId != null && it.value.tipo == item.tipo && it.value.tmdbId == item.tmdbId
            }?.key
            if (duplicateKey != null && duplicateKey != item.id) merged.remove(duplicateKey)
            merged[item.id] = item
        }
        return base.copy(
            items = merged.values.toList(),
            updatedAt = maxOf(base.updatedAt.orEmpty(), manual.actualizadoEn.orEmpty()),
            sourceLabel = "${base.sourceLabel} + ${manual.items.size} manuales"
        )
    }

    private fun readManualCatalog(profileId: String): CatalogoResponse? = runCatching {
        val file = manualFile(profileId)
        if (!file.exists()) return null
        val snapshot = validator.validate(file.readText(), "Entradas manuales")
        CatalogoResponse(snapshot.schemaVersion, snapshot.updatedAt, snapshot.items)
    }.onFailure { logError(profileId, "Catálogo manual inválido: ${safeMessage(it)}") }.getOrNull()

    private fun saveManualCatalog(profileId: String, items: List<VideoItem>) {
        if (items.isEmpty()) {
            backupIfPresent(manualFile(profileId))
            manualFile(profileId).delete()
            return
        }
        val response = CatalogoResponse("1.0", Instant.now().toString(), items)
        val json = prettyGson.toJson(response)
        validator.validate(json, "Entradas manuales")
        backupIfPresent(manualFile(profileId))
        atomicSave(manualFile(profileId), json)
    }

    private fun backupIfPresent(file: File) {
        if (!file.exists()) return
        val backup = File(file.parentFile, "${file.nameWithoutExtension}.backup.json")
        file.copyTo(backup, overwrite = true)
    }

    private fun loadCache(profileId: String, file: File, label: String, cached: Boolean): CatalogSnapshot? =
        runCatching {
            if (!file.exists()) return null
            validator.validate(file.readText(), label).copy(usingCachedCopy = cached)
        }.onFailure { logError(profileId, "Copia almacenada inválida: ${safeMessage(it)}") }.getOrNull()

    private fun loadFallback(label: String, cached: Boolean): CatalogSnapshot {
        val json = context.assets.open("catalogo_fallback.json").bufferedReader().use { it.readText() }
        return validator.validate(json, label).copy(usingCachedCopy = cached)
    }

    private fun atomicSave(target: File, json: String) {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, "${target.name}.tmp")
        temp.writeText(json)
        if (!temp.renameTo(target)) {
            temp.copyTo(target, overwrite = true)
            temp.delete()
        }
    }

    private fun remoteFile(profileId: String) = File(store.profileDir(profileId), "catalog_remote.json")
    private fun localFile(profileId: String) = File(store.profileDir(profileId), "catalog_local.json")
    private fun manualFile(profileId: String) = File(store.profileDir(profileId), "catalog_manual.json")
    private fun errorFile(profileId: String) = File(store.profileDir(profileId), "errors.log")

    private fun logError(profileId: String, message: String) {
        runCatching { errorFile(profileId).appendText("${System.currentTimeMillis()} | $message\n") }
    }

    private fun safeMessage(error: Throwable): String =
        (error.message ?: error.javaClass.simpleName).replace(Regex("Bearer\\s+\\S+", RegexOption.IGNORE_CASE), "Bearer ***")

    private fun directoryBytes(file: File): Long = when {
        !file.exists() -> 0L
        file.isFile -> file.length()
        else -> file.listFiles()?.sumOf(::directoryBytes) ?: 0L
    }
}
