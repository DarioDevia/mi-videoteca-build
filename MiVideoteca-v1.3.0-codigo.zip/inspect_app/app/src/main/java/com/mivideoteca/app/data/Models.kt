package com.mivideoteca.app.data

import com.google.gson.annotations.SerializedName

data class CatalogoResponse(
    @SerializedName("schema_version") val schemaVersion: String = "1.0",
    @SerializedName("actualizado_en") val actualizadoEn: String? = null,
    val items: List<VideoItem> = emptyList()
)

data class VideoItem(
    val id: String,
    val tipo: String,
    val titulo: String,
    @SerializedName("titulo_original") val tituloOriginal: String? = null,
    @SerializedName("titulos_alternativos") val titulosAlternativos: List<String> = emptyList(),
    val year: Int? = null,
    val generos: List<String> = emptyList(),
    val calidad: String? = null,
    val duracion: String? = null,
    val sinopsis: String? = null,
    @SerializedName("poster_url") val posterUrl: String? = null,
    @SerializedName("backdrop_url") val backdropUrl: String? = null,
    @SerializedName("trailer_url") val trailerUrl: String? = null,
    @SerializedName("tmdb_id") val tmdbId: Long? = null,
    @SerializedName("anilist_id") val anilistId: Long? = null,
    @SerializedName("telegram_url") val telegramUrl: String? = null,
    @SerializedName("fecha_agregado") val fechaAgregado: String? = null,
    val audio: String? = null,
    val subtitulos: String? = null,
    val temporadas: List<Season> = emptyList()
)

data class Season(
    val numero: Int,
    val titulo: String? = null,
    val episodios: List<Episode> = emptyList()
)

data class Episode(
    val id: String,
    val numero: Int,
    val titulo: String? = null,
    val duracion: String? = null,
    @SerializedName("thumbnail_url") val thumbnailUrl: String? = null,
    @SerializedName("telegram_url") val telegramUrl: String? = null
)

data class ValidationIssue(val index: Int, val itemId: String?, val message: String)

data class CatalogSnapshot(
    val schemaVersion: String,
    val updatedAt: String?,
    val items: List<VideoItem>,
    val issues: List<ValidationIssue>,
    val loadedAtMillis: Long,
    val sourceLabel: String,
    val usingCachedCopy: Boolean = false
)

data class UserProgress(
    val itemId: String,
    val lastEpisodeId: String? = null,
    val watchedItem: Boolean = false,
    val watchedEpisodeIds: Set<String> = emptySet(),
    val lastAccessMillis: Long = 0L
)

enum class CatalogSource { REMOTE, LOCAL }
enum class ThemeMode { SYSTEM, DARK, LIGHT }
enum class SortMode { TITLE, RECENT, YEAR, LAST_VIEWED }

data class AppPreferences(
    val profileId: String = "mi_videoteca",
    val profileName: String = "Mi Videoteca",
    val source: CatalogSource = CatalogSource.REMOTE,
    val remoteUrl: String = CatalogRepository.DEFAULT_URL,
    val localFileName: String? = null,
    val tmdbToken: String = "",
    val metadataLanguage: String = "es-AR",
    val themeMode: ThemeMode = ThemeMode.DARK,
    val showAnime: Boolean = true,
    val showMovies: Boolean = true,
    val showSeries: Boolean = true,
    val sortMode: SortMode = SortMode.RECENT,
    val rememberOpenedEpisodes: Boolean = true,
    val markWatchedOnOpen: Boolean = false,
    val confirmMarkWatched: Boolean = true,
    val openWithTelegram: Boolean = true,
    val autoplayTrailers: Boolean = true,
    val telegramMovieChatId: String = "",
    val telegramMovieChannelTitle: String? = null,
    val catalogPublishUrl: String = ""
)

data class ServiceStatus(
    val catalog: String = "Sin probar",
    val tmdb: String = "Sin probar",
    val anilist: String = "Sin probar",
    val telegram: String = "Sin probar"
)
