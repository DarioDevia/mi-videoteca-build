package com.mivideoteca.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SecureSecretStore(context: Context) {
    private val preferences = context.getSharedPreferences("secure_secrets_v1", Context.MODE_PRIVATE)
    private val alias = "mivideoteca_telegram_secrets_v1"

    fun hasTelegramBotToken(): Boolean = preferences.contains(KEY_TELEGRAM_TOKEN)

    fun saveTelegramBotToken(token: String) {
        val clean = token.trim()
        require(clean.isNotBlank()) { "El token del bot no puede estar vacío." }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(clean.toByteArray(Charsets.UTF_8))
        val value = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(encrypted, Base64.NO_WRAP)
        preferences.edit().putString(KEY_TELEGRAM_TOKEN, value).commit()
    }

    fun getTelegramBotToken(): String? {
        val value = preferences.getString(KEY_TELEGRAM_TOKEN, null) ?: return null
        return runCatching {
            val parts = value.split(':', limit = 2)
            require(parts.size == 2)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), Charsets.UTF_8)
        }.getOrNull()
    }

    fun clearTelegramBotToken() {
        preferences.edit().remove(KEY_TELEGRAM_TOKEN).commit()
    }

    fun hasCatalogAdminToken(): Boolean = preferences.contains(KEY_CATALOG_ADMIN_TOKEN)

    fun saveCatalogAdminToken(token: String) {
        saveEncrypted(KEY_CATALOG_ADMIN_TOKEN, token, "La clave administrativa no puede estar vacía.")
    }

    fun getCatalogAdminToken(): String? = getEncrypted(KEY_CATALOG_ADMIN_TOKEN)

    private fun secretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
            init(
                KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            generateKey()
        }
    }

    private fun saveEncrypted(key: String, value: String, emptyMessage: String) {
        val clean = value.trim()
        require(clean.isNotBlank()) { emptyMessage }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(clean.toByteArray(Charsets.UTF_8))
        val encoded = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(encrypted, Base64.NO_WRAP)
        preferences.edit().putString(key, encoded).commit()
    }

    private fun getEncrypted(key: String): String? {
        val value = preferences.getString(key, null) ?: return null
        return runCatching {
            val parts = value.split(':', limit = 2)
            require(parts.size == 2)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), Charsets.UTF_8)
        }.getOrNull()
    }

    private companion object {
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val KEY_TELEGRAM_TOKEN = "telegram_bot_token"
        const val KEY_CATALOG_ADMIN_TOKEN = "catalog_admin_token"
    }
}
