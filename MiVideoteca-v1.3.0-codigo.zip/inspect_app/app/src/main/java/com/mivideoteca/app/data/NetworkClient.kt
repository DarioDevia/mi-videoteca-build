package com.mivideoteca.app.data

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

object NetworkClient {
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()
}
