package com.mivideoteca.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

object TelegramLauncher {
    private val packages = listOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram")

    fun isInstalled(context: Context): Boolean = packages.any { packageName ->
        try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) { false }
    }

    fun open(context: Context, url: String, preferTelegram: Boolean = true): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        if (uri.scheme != "https" || uri.host !in setOf("t.me", "telegram.me")) return false
        if (preferTelegram) {
            packages.forEach { packageName ->
                try {
                    context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { setPackage(packageName) })
                    return true
                } catch (_: ActivityNotFoundException) { }
            }
        }
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
            true
        } catch (_: Exception) { false }
    }
}
