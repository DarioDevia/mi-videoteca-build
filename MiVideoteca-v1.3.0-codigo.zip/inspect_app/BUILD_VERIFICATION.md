# Verificación de la entrega

- Compilación limpia `assembleDebug`: correcta.
- Pruebas unitarias: 7 correctas (3 del catálogo, 3 de formato/banderas y 1 de catálogo manual exportable).
- APK: estructura ZIP íntegra.
- Firma: Android Debug, APK Signature Scheme v2 verificado.
- Package: `com.mivideoteca.app`.
- Version: `1.2.0` (`versionCode` 3).
- Android mínimo: API 26 / Android 8.0.
- Target y compile SDK: API 34 / Android 14.
- SHA-256: `c9bdeb15fae26fc26de18dd363b3bd02727702483a50bfe51554741ef6cd87ec`.

También se verificó que la APK incorpora Administración de películas, configuración cifrada del Bot Token, publicación por Bot API, altas manuales persistentes, exportación/compartir de `catalogo.json` y el cliente de publicación remota autenticada.

La URL inicial del Worker se consultó durante la verificación y devolvió un catálogo con `schema_version: 1` y una entrada válida de AniList. El validador acepta expresamente tanto `1` como cadenas `1.x`.

No se ejecutó una prueba de interfaz en un teléfono físico porque este entorno no tiene un dispositivo Android conectado. La APK sí fue compilada, empaquetada y verificada con las herramientas oficiales del SDK.

La APK de esta entrega usa una clave Android Debug generada en este entorno. Su certificado no coincide con el de la APK de la entrega anterior; Android exigirá desinstalar aquella APK antes de instalar esta, salvo que se vuelva a firmar el nuevo paquete con la clave privada original. El código y el `applicationId` sí continúan el proyecto existente.
